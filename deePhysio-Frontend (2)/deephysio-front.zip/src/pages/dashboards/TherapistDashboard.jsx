import React, { useState, useEffect } from 'react';
import { fetchApi } from '../../config/api';
import { FaCalendarAlt, FaUserInjured, FaComments, FaHeartbeat } from 'react-icons/fa';
import PageHeader from '../../components/ui/PageHeader';
import ClinicalNoteIcon from '../../components/ui/ClinicalNoteIcon';

const StatCard = ({ title, value, icon, color, trend }) => (
  <div className="p-4 bg-white border border-slate-200 rounded-lg flex flex-col items-start">
    <div className="flex items-center justify-between w-full mb-3">
      <div className={`w-8 h-8 flex items-center justify-center rounded bg-opacity-10 ${color}`}>
        <span className={`text-sm ${color.replace('bg-', 'text-')}`}>{icon}</span>
      </div>
      <div className="px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider bg-slate-50 text-slate-500 border border-slate-100">
        {trend}
      </div>
    </div>
    <div>
      <p className="text-slate-500 text-[9px] font-bold uppercase tracking-widest mb-1">{title}</p>
      <h3 className="text-xl font-bold text-slate-800 tracking-tight leading-none">{value}</h3>
    </div>
  </div>
);

const TherapistDashboard = () => {
  const [stats, setStats] = useState({
    appointments: 0,
    patients: 0,
    pendingNotes: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const [apptRes, patRes, notesRes] = await Promise.all([
          fetchApi('/appointments'),
          fetchApi('/patients'),
          fetchApi('/clinical-notes')
        ]);

        const allAppointments = apptRes?.ok ? (await apptRes.json()).data || [] : [];
        const patients = patRes?.ok ? (await patRes.json()).data || [] : [];
        const notes = notesRes?.ok ? (await notesRes.json()).data || [] : [];

        const todayStr = new Date().toISOString().split('T')[0];
        const todayAppts = allAppointments.filter(a => {
          if (!a.appointment_date) return false;
          return a.appointment_date.split('T')[0] === todayStr;
        });

        // Draft or missing notes count approximation
        const pendingNotes = notes.filter(n => n.status === 'draft').length;

        setStats({
          appointments: todayAppts.length,
          patients: patients.length,
          pendingNotes: pendingNotes
        });
      } catch (e) {
        console.error("Error fetching therapist dashboard stats:", e);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboardData();
  }, []);

  return (
    <div className="space-y-5 animate-fade-in custom-scrollbar p-1 sm:p-2 md:p-1">
      <PageHeader
        title="My Dashboard"
        subtitle="Welcome back 👋 Here's your schedule for today."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard title="Today's Appointments" value={loading ? "..." : stats.appointments} icon={<FaCalendarAlt />} color="bg-clinicPrimary" trend="Today" />
        <StatCard title="Pending Notes" value={loading ? "..." : stats.pendingNotes} icon={<ClinicalNoteIcon size={18} />} color="bg-rose-500" trend="Action Req" />
        <StatCard title="My Patients" value={loading ? "..." : stats.patients} icon={<FaUserInjured />} color="bg-emerald-500" trend="Active" />
        <StatCard title="Treatment Plans" value="0" icon={<FaHeartbeat />} color="bg-indigo-500" trend="Active" />
        <StatCard title="Exercise Plans" value="0" icon={<FaHeartbeat />} color="bg-purple-500" trend="Active" />
        <StatCard title="Messages" value="0" icon={<FaComments />} color="bg-sky-500" trend="Unread" />
      </div>
      
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-3 flex items-center justify-between border-b border-slate-100 bg-slate-50/50">
          <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Today's Schedule</h3>
        </div>
        <div className="p-8 text-center text-slate-400 text-sm">
          No appointments scheduled for the remainder of the day.
        </div>
      </div>
    </div>
  );
};

export default TherapistDashboard;
