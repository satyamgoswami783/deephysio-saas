import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'

// One-time cleanup: Clear legacy persistent tokens from localStorage
// to ensure the new sessionStorage-based manual login takes immediate effect.
const keysToClear = ['token', 'deephysio_user', 'deephysio_role'];
keysToClear.forEach(key => {
  if (localStorage.getItem(key)) {
    localStorage.removeItem(key);
  }
});


ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
