export const MODULES = [
  'Dashboard',
  'Appointments',
  'Patients',
  'Clinical Notes',
  'Communication',
  'Billing',
  'Forms',
  'Analytics',
  'Settings'
];

export const SUPERADMIN_MODULES = [
  'Dashboard',
  'Admins',
  'Payments',
  'Setting',
  'Support Tickets'
];

export const ROLE_DEFAULTS = {
  superadmin: SUPERADMIN_MODULES,
  admin: MODULES,
  therapist: [
    'Dashboard',
    'Appointments',
    'Patients',
    'Clinical Notes',
    'Communication',
    'Forms',
    'Analytics'
  ],
  receptionist: [
    'Dashboard',
    'Appointments',
    'Patients',
    'Communication',
    'Forms',
    'Analytics'
  ],
  billing: ['Dashboard', 'Billing', 'Analytics', 'Communication']
};

export const MODULE_ALIASES = {
  'Billing & Payments': 'Billing'
};

export const normalizeModule = (name) => MODULE_ALIASES[name] || name;

export const readAllowedModules = (userLike, role = 'therapist') => {
  const normalizedRole = role?.toLowerCase();
  
  // SuperAdmins always get all modules, ignoring legacy DB limitations
  if (normalizedRole === 'superadmin') {
    return ROLE_DEFAULTS.superadmin || MODULES;
  }

  if (!userLike || typeof userLike !== 'object') {
    return ROLE_DEFAULTS[normalizedRole] || [];
  }

  const fromSnake = userLike.allowed_menus;
  const fromCamel = userLike.allowedMenus;
  const explicit = Array.isArray(fromSnake) ? fromSnake : (Array.isArray(fromCamel) ? fromCamel : null);

  if (explicit !== null) {
    const valid = explicit.map(normalizeModule).filter((m) => MODULES.includes(m));
    return [...new Set(valid)];
  }

  const resolvedRole = String(userLike.role || role || 'therapist').toLowerCase();
  return (ROLE_DEFAULTS[resolvedRole] || []).map(normalizeModule);
};
