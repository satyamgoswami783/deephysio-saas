import React from 'react';
import { FaBuilding, FaUsers, FaShieldAlt, FaBell, FaPuzzlePiece, FaChevronRight, FaDoorOpen } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const Settings = () => {
  const navigate = useNavigate();

  const settingsCards = [
    {
      id: 'general',
      title: 'General Settings',
      description: 'Manage clinic details, contact information, tax configuration, and configuration.',
      icon: <FaBuilding className="text-blue-500" size={24} />,
      path: '/settings/clinic',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-100'
    },
    {
      id: 'users',
      title: 'User Management',
      description: 'Manage staff profiles, system access, and add/edit users.',
      icon: <FaUsers className="text-emerald-500" size={24} />,
      path: '/settings/users',
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-100'
    },
    {
      id: 'security',
      title: 'Security',
      description: 'Update account passwords, configure 2FA, and manage security.',
      icon: <FaShieldAlt className="text-purple-500" size={24} />,
      path: '/settings/security',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-100'
    },
    {
      id: 'notifications',
      title: 'Notifications',
      description: 'Configure email alerts, SMS settings, and system notifications.',
      icon: <FaBell className="text-amber-500" size={24} />,
      path: '/settings/notifications',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-100'
    },
    {
      id: 'rooms',
      title: 'Room Settings',
      description: 'Manage room list used in appointment booking.',
      icon: <FaDoorOpen className="text-teal-500" size={24} />,
      path: '/settings/rooms',
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-100'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in font-sans">
      <div className="mb-10">
         <h1 className="text-3xl font-black text-slate-900 tracking-tight">System Settings</h1>
         <p className="text-slate-500 mt-2 font-medium text-sm">Configure and manage your clinic preferences and operations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {settingsCards.map((card) => (
          <div 
            key={card.id} 
            onClick={() => navigate(card.path)}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex flex-col cursor-pointer hover:shadow-google hover:border-clinicPrimary/30 hover:-translate-y-1 transition-all group"
          >
            <div className={`w-14 h-14 rounded-2xl ${card.bgColor} ${card.borderColor} border flex items-center justify-center mb-5 group-hover:scale-110 transition-transform`}>
              {card.icon}
            </div>
            
            <h2 className="text-lg font-bold text-slate-800 mb-2 group-hover:text-clinicPrimary transition-colors tracking-tight">{card.title}</h2>
            <p className="text-sm text-slate-500 leading-relaxed flex-1">{card.description}</p>
            
            <div className="mt-6 flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-clinicPrimary opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all">
               Manage Settings <FaChevronRight size={10} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Settings;
