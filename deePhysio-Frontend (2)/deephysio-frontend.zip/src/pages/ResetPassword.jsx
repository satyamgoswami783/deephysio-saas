import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { FaHeartbeat, FaLock, FaCheckCircle, FaExclamationTriangle } from 'react-icons/fa';
import { useToast } from '../context/ToastContext';
import { fetchApi } from '../config/api';

const ResetPassword = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const { showToast } = useToast();

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleReset = async (e) => {
    e.preventDefault();

    if (!token) {
      showToast('Invalid reset link. No token found.', 'error');
      return;
    }

    if (password.length < 6) {
      showToast('Password must be at least 6 characters.', 'error');
      return;
    }

    if (password !== confirmPassword) {
      showToast('Passwords do not match.', 'error');
      return;
    }

    setLoading(true);
    try {
      const res = await fetchApi('/auth/reset-password', {
        method: 'POST',
        body: JSON.stringify({ token, newPassword: password })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        showToast(data.message || 'Failed to reset password.', 'error');
        return;
      }

      setIsSuccess(true);
      showToast('Password reset successful! You can now login.', 'success');
      
      // Auto-redirect after 3 seconds
      setTimeout(() => {
        navigate('/login');
      }, 3000);
    } catch (err) {
      showToast('Network error while resetting password.', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-mesh flex items-center justify-center p-6 font-outfit">
        <div className="w-full max-w-md bg-white p-10 rounded-[2.5rem] shadow-premium border border-slate-100 text-center animate-slide-up">
          <div className="w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-emerald-100">
            <FaCheckCircle className="text-emerald-500" size={40} />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">All Set!</h1>
          <p className="text-[13px] font-bold text-slate-400 mt-3 leading-relaxed">
            Your password has been changed successfully. You will be redirected to the login page shortly.
          </p>
          <button 
            onClick={() => navigate('/login')}
            className="mt-8 w-full py-3.5 bg-clinicPrimary text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-clinicPrimaryDark transition-all"
          >
            Go to Login
          </button>
        </div>
      </div>
    );
  }

  if (!token) {
    return (
      <div className="min-h-screen bg-mesh flex items-center justify-center p-6 font-outfit">
        <div className="w-full max-w-md bg-white p-10 rounded-[2.5rem] shadow-premium border border-rose-100 text-center animate-slide-up">
          <div className="w-20 h-20 bg-rose-50 rounded-3xl flex items-center justify-center mx-auto mb-6 border border-rose-100">
            <FaExclamationTriangle className="text-rose-500" size={40} />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Invalid Link</h1>
          <p className="text-[13px] font-bold text-slate-400 mt-3 leading-relaxed">
            The password reset link is invalid or has expired. Please request a new one from the login page.
          </p>
          <button 
            onClick={() => navigate('/login')}
            className="mt-8 w-full py-3.5 bg-slate-900 text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all"
          >
            Back to Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-mesh flex items-center justify-center p-6 relative overflow-hidden font-outfit">
      <div className="absolute top-[-15%] left-[-5%] w-[60vw] h-[60vw] bg-clinicPrimary/10 rounded-full blur-[140px] pointer-events-none"></div>
      
      <div className="w-full max-w-[480px] relative z-10 animate-slide-up">
        <div className="bg-white/80 backdrop-blur-3xl p-10 rounded-[2.5rem] shadow-premium border border-white/60">
          <div className="flex justify-center mb-8">
            <div className="w-16 h-16 bg-white rounded-[1.5rem] shadow-premium flex items-center justify-center border border-slate-100">
              <FaHeartbeat size={32} className="text-clinicPrimary" />
            </div>
          </div>

          <h1 className="text-3xl font-black text-slate-900 tracking-tight text-center">Reset Password</h1>
          <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] mt-3 mb-10 text-center">Secure Account Recovery</p>

          <form onSubmit={handleReset} className="space-y-5">
            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">New Password</label>
              <div className="relative">
                <FaLock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={12}/>
                <input 
                  type="password" 
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-100 rounded-xl text-[13px] font-bold text-slate-700 outline-none focus:ring-4 focus:ring-clinicPrimary/10 transition-all" 
                  placeholder="Enter secure password" 
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Confirm Password</label>
              <div className="relative">
                <FaLock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={12}/>
                <input 
                  type="password" 
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-100 rounded-xl text-[13px] font-bold text-slate-700 outline-none focus:ring-4 focus:ring-clinicPrimary/10 transition-all" 
                  placeholder="Repeat secure password" 
                />
              </div>
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="w-full py-4 bg-clinicPrimary text-white shadow-xl shadow-clinicPrimary/20 rounded-xl font-black text-[11px] uppercase tracking-widest hover:bg-clinicPrimaryDark hover:scale-[1.01] active:scale-95 transition-all text-center cursor-pointer disabled:bg-slate-400"
            >
              {loading ? 'Processing...' : 'Securely Reset Password'}
            </button>
          </form>
          
          <div className="mt-8 text-center">
            <button 
              onClick={() => navigate('/login')}
              className="text-[10px] font-bold text-slate-400 hover:text-clinicPrimary transition-colors"
            >
              Cancel and Return to Login
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
