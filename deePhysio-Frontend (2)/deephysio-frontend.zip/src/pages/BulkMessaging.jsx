import React, { useMemo, useState } from 'react';
import { FaUsers, FaSms, FaEnvelope, FaPaperPlane, FaCheckCircle, FaChevronRight, FaSearch } from 'react-icons/fa';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { fetchApi } from '../config/api';

const BulkMessaging = () => {
  const role = sessionStorage.getItem('deephysio_role')?.toLowerCase();
  const canWrite = role === 'admin' || role === 'billing' || role === 'administrator';
  const [selectedPatients, setSelectedPatients] = useState([]);
  const [message, setMessage] = useState('');
  const [channel, setChannel] = useState('sms');
  const [isSending, setIsSending] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: '' });

  const [patients, setPatients] = useState([]);
  const [patientSearch, setPatientSearch] = useState('');
  const [visiblePatientsCount, setVisiblePatientsCount] = useState(9);

  React.useEffect(() => {
    const loadPatients = async () => {
      try {
        const response = await fetchApi('/patients');
        if (!response) return;
        const json = await response.json();
        const mapped = (json?.data || []).map((p) => ({
          id: p.id,
          name: `${p.firstName || p.first_name || ''} ${p.lastName || p.last_name || ''}`.trim() || `Patient ${p.id}`
        }));
        setPatients(mapped);
      } catch (error) {
        setPatients([]);
      }
    };
    loadPatients();
  }, []);

  const handleSelectPatient = (id) => {
    if (selectedPatients.includes(id)) {
      setSelectedPatients(selectedPatients.filter(pId => pId !== id));
    } else {
      setSelectedPatients([...selectedPatients, id]);
    }
  };

  const filteredPatients = useMemo(() => {
    const term = patientSearch.trim().toLowerCase();
    if (!term) return patients;
    return patients.filter((patient) => patient.name.toLowerCase().includes(term));
  }, [patients, patientSearch]);

  const visiblePatients = useMemo(
    () => filteredPatients.slice(0, visiblePatientsCount),
    [filteredPatients, visiblePatientsCount]
  );

  const canSeeMore = filteredPatients.length > visiblePatientsCount;

  const handleSelectAll = () => {
    const filteredIds = filteredPatients.map((p) => p.id);
    const allFilteredSelected = filteredIds.length > 0 && filteredIds.every((id) => selectedPatients.includes(id));

    if (allFilteredSelected) {
      setSelectedPatients((prev) => prev.filter((id) => !filteredIds.includes(id)));
    } else {
      setSelectedPatients((prev) => {
        const merged = new Set([...prev, ...filteredIds]);
        return Array.from(merged);
      });
    }
  };

  const handleSearchChange = (value) => {
    setPatientSearch(value);
    setVisiblePatientsCount(9);
  };

  const handleSendMessage = async () => {
    if (selectedPatients.length === 0 || !message.trim()) return;
    
    setIsSending(true);
    try {
      const response = await fetchApi('/communication/campaigns', {
        method: 'POST',
        body: JSON.stringify({
          channel,
          message,
          recipients: selectedPatients
        })
      });
      if (!response) return;
      const json = await response.json();
      if (!json.success) {
        setToast({ visible: true, message: json.message || 'Campaign send failed' });
        return;
      }
      setIsSending(false);
      setToast({ visible: true, message: `Message sent to ${selectedPatients.length} patients via ${channel.toUpperCase()}` });
      setSelectedPatients([]);
      setMessage('');
      setTimeout(() => setToast({ visible: false, message: '' }), 3000);
    } catch (error) {
      setIsSending(false);
      setToast({ visible: true, message: 'Campaign send failed' });
      setTimeout(() => setToast({ visible: false, message: '' }), 3000);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-3 px-4 sm:px-5 py-4 animate-fade-in font-sans">
      {/* Toast Notification */}
      {toast.visible && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-[9999] animate-in slide-in-from-top-4 duration-300">
          <div className="px-6 py-2 bg-slate-900 text-white rounded-xl shadow-xl flex items-center gap-3 border border-white/10">
            <FaCheckCircle className="text-clinicPrimary" size={12} />
            <span className="text-[10px] font-black uppercase tracking-widest">{toast.message}</span>
          </div>
        </div>
      )}

      <div className="mb-0.5">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight uppercase leading-none whitespace-nowrap">Bulk Messaging</h1>
        <p className="text-slate-500 font-bold mt-0.5 uppercase tracking-wider text-[9px] opacity-80 whitespace-nowrap overflow-hidden text-ellipsis">Send updates or reminders to multiple patients at once.</p>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {/* Step 1: Select Patients */}
        <Card hover={false} className="p-3.5 sm:p-4 border border-slate-200 shadow-sm bg-white rounded-2xl overflow-hidden">
          <div className="flex justify-between items-center gap-2 mb-2.5">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-2 whitespace-nowrap">
              <FaUsers className="text-clinicPrimary" size={10} /> 1. Select Patients
            </label>
            <button 
              onClick={handleSelectAll}
              className="text-[10px] font-black text-clinicPrimary uppercase tracking-wider hover:opacity-70 transition-opacity whitespace-nowrap"
            >
              {filteredPatients.length > 0 && filteredPatients.every((p) => selectedPatients.includes(p.id)) ? 'Deselect All' : 'Select All'}
            </button>
          </div>

          <div className="relative mb-2.5">
            <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={12} />
            <input
              type="text"
              value={patientSearch}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="Search patients..."
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 bg-slate-50 text-[12px] font-semibold text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-clinicPrimary/15 focus:border-clinicPrimary/40"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5">
            {visiblePatients.length > 0 ? (
              visiblePatients.map((patient) => (
                <button
                  type="button"
                  key={patient.id}
                  onClick={() => handleSelectPatient(patient.id)}
                  className={`w-full p-2 rounded-xl border text-[11px] font-bold cursor-pointer transition-all flex justify-between items-center text-left ${
                    selectedPatients.includes(patient.id)
                      ? 'bg-clinicPrimary/5 border-clinicPrimary text-clinicPrimary'
                      : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <span className="truncate pr-2">{patient.name}</span>
                  {selectedPatients.includes(patient.id) && <FaCheckCircle size={10} className="shrink-0" />}
                </button>
              ))
            ) : (
              <div className="sm:col-span-2 lg:col-span-3 py-6 text-center text-[12px] font-semibold text-slate-500 border border-dashed border-slate-200 rounded-xl bg-slate-50">
                No patient found for this search
              </div>
            )}
          </div>

          <div className="mt-2.5 pt-2.5 border-t border-slate-100 flex justify-between items-center gap-2">
             <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider whitespace-nowrap">
                Selected: <span className="text-clinicPrimary">{selectedPatients.length}</span> / {patients.length}
             </span>
             <div className="flex items-center gap-3 whitespace-nowrap">
               {canSeeMore && (
                 <button
                   type="button"
                   onClick={() => setVisiblePatientsCount((prev) => prev + 9)}
                   className="text-[10px] font-black uppercase tracking-wider text-clinicPrimary hover:opacity-75 transition-opacity"
                 >
                   See More
                 </button>
               )}
               {visiblePatientsCount > 9 && (
                 <button
                   type="button"
                   onClick={() => setVisiblePatientsCount(9)}
                   className="text-[10px] font-black uppercase tracking-wider text-slate-500 hover:text-slate-700 transition-colors"
                 >
                   See Less
                 </button>
               )}
             </div>
          </div>
        </Card>

        {/* Step 2: Message Input */}
        <Card hover={false} className="p-3.5 sm:p-4 border border-slate-200 shadow-sm bg-white rounded-2xl">
          <label className="text-[9px] font-black text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2 whitespace-nowrap">
            <FaPaperPlane className="text-clinicPrimary" size={10} /> 2. Message Content
          </label>
          <textarea 
            className="w-full h-24 p-3 bg-slate-50 border border-slate-200 rounded-2xl text-[12px] font-bold text-slate-800 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary resize-none transition-all placeholder:text-slate-400"
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
        </Card>

        {/* Step 3: Channel Selection */}
        <Card hover={false} className="p-3.5 sm:p-4 border border-slate-200 shadow-sm bg-white rounded-2xl">
          <label className="text-[9px] font-black text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-2 whitespace-nowrap">
            <FaChevronRight className="text-clinicPrimary rotate-90" size={10} /> 3. Select Channel
          </label>
          <div className="flex justify-center gap-3">
            <button 
              onClick={() => setChannel('sms')}
              className={`flex-1 max-w-[160px] flex items-center justify-center gap-2 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${
                channel === 'sms' 
                  ? 'bg-clinicPrimary text-white shadow-lg shadow-clinicPrimary/20 border-clinicPrimary' 
                  : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <FaSms size={14} /> SMS
            </button>
            <button 
              onClick={() => setChannel('email')}
              className={`flex-1 max-w-[160px] flex items-center justify-center gap-2 py-2.5 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${
                channel === 'email' 
                  ? 'bg-clinicPrimary text-white shadow-lg shadow-clinicPrimary/20 border-clinicPrimary' 
                  : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'
              }`}
            >
              <FaEnvelope size={14} /> Email
            </button>
          </div>
        </Card>

        {/* Action Button */}
        <div className="pt-4 flex justify-center">
          <Button 
            variant="accent" 
            className="w-full max-w-[280px] h-11 rounded-xl shadow-xl shadow-clinicPrimary/10 text-[10px] font-black uppercase tracking-[0.2em] transition-all active:scale-95 disabled:opacity-50"
            onClick={handleSendMessage}
            disabled={!canWrite || isSending || selectedPatients.length === 0 || !message.trim()}
          >
            {isSending ? 'Sending Messages...' : 'Send Message'}
          </Button>
        </div>
        {!canWrite && <p className="text-center text-[9px] font-bold text-amber-600 mt-2">Read-only access: admin/billing can send bulk campaigns.</p>}
        <p className="text-center text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-3">
          Patient privacy and consent will be verified before delivery.
        </p>
      </div>
    </div>
  );
};

export default BulkMessaging;
