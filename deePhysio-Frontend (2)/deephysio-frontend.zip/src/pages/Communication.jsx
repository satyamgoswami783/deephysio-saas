import React, { useState, useRef, useEffect } from 'react';
import { 
  FaPlus, FaSearch, FaChevronRight, FaPhoneAlt, FaEnvelope, 
  FaCommentAlt, FaPaperPlane, FaWhatsapp, FaInfoCircle, 
  FaRegClock, FaSmile, FaPaperclip, FaCamera, FaCheck, FaCheckDouble,
  FaFileAlt, FaTimes
} from 'react-icons/fa';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';

const Communication = () => {
  const [activeTab, setActiveTab] = useState('sms');
  const [isCommModalOpen, setIsCommModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeThreadId, setActiveThreadId] = useState(1);
  const [messageText, setMessageText] = useState('');
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const role = sessionStorage.getItem('deephysio_role');


  const isTherapist = role === 'therapist';
  const isReceptionist = role === 'receptionist';

  const [conversations, setConversations] = useState([
    { id: 1, name: 'James Wilson', initial: 'JW', lastMsg: 'Protocol evaluated.', time: '10:45 AM', status: 'online', unreadCount: 0, lastMsgStatus: 'read' },
    { id: 2, name: 'Sarah Thompson', initial: 'ST', lastMsg: 'Imaging results ready.', time: '09:30 AM', status: 'online', unreadCount: 3, lastMsgStatus: 'delivered' },
    { id: 3, name: 'Robert Davis', initial: 'RD', lastMsg: 'Next session confirmed.', time: 'Yesterday', status: 'offline', unreadCount: 0, lastMsgStatus: 'sent' },
    { id: 4, name: 'Emily Brown', initial: 'EB', lastMsg: 'Payment link received.', time: 'Yesterday', status: 'online', unreadCount: 0, lastMsgStatus: 'read' },
  ]);

  const [chatHistory, setChatHistory] = useState([
    { id: 1, sender: 'James Wilson', initial: 'JW', text: "Subject: Protocol Authentication. Just confirming tomorrow's evaluation window at 10:00 AM clinical time. Is the station authenticated?", time: '10:42 AM', isMe: false, status: 'read' },
    { id: 2, sender: 'You', initial: 'KP', text: "Access Granted James. Protocol window 10:00-11:00 is authenticated. Your progression data has been synchronized for validation.", time: '10:45 AM', isMe: true, status: 'read' },
  ]);

  const [showTemplates, setShowTemplates] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);
  const chatEndRef = useRef(null);

  const MESSAGE_TEMPLATES = [
    { name: 'Appointment Reminder', text: 'Hi! Just a friendly reminder of your physiotherapy appointment tomorrow at [Time]. Please let us know if you can attend.' },
    { name: 'Follow-up Message', text: 'Hi, how is your recovery progressing after the last session? Let us know if you have any questions about your HEP.' },
    { name: 'Cancellation Notice', text: 'We have received your request to cancel your appointment. Please use this link to reschedule: [Link]' }
  ];

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory]);

  const handleSendMessage = () => {
    if (!messageText.trim() && !selectedFile) return;
    const newMessage = {
      id: Date.now(),
      sender: 'You',
      initial: 'KP',
      text: messageText,
      file: selectedFile,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
      status: 'sent'
    };
    setChatHistory([...chatHistory, newMessage]);
    setMessageText('');
    setSelectedFile(null);
    
    // Simulate delivery/read
    setTimeout(() => {
        setChatHistory(prev => prev.map(m => m.id === newMessage.id ? { ...m, status: 'delivered' } : m));
    }, 1500);
    setTimeout(() => {
        setChatHistory(prev => prev.map(m => m.id === newMessage.id ? { ...m, status: 'read' } : m));
    }, 3000);
  };

  const applyTemplate = (text) => {
    setMessageText(text);
    setShowTemplates(false);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
        setSelectedFile({
            name: file.name,
            size: (file.size / 1024).toFixed(1) + ' KB',
            type: file.type
        });
    }
  };

  const handleBroadcast = () => {
    setIsBroadcasting(true);
    setTimeout(() => {
      setIsBroadcasting(false);
      setIsCommModalOpen(false);
      alert('Broadcast Sync Executed Successfully to all target nodes.');
    }, 2000);
  };

  const filteredConversations = conversations.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeThread = conversations.find(c => c.id === activeThreadId) || conversations[0];

  return (
    <div className="space-y-4 sm:space-y-6 px-4 sm:px-5 lg:px-6 animate-fade-in custom-scrollbar font-sans relative">
      <Card hover={false} className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 sm:gap-6 p-4 sm:p-5 border border-slate-100 shadow-none bg-white relative overflow-hidden group">
        <div className="relative z-10">
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tighter uppercase leading-none">Communication Hub</h1>
          <p className="text-slate-500 font-bold mt-1.5 uppercase tracking-widest text-[9px] sm:text-[10px] opacity-80">Manage patient interactions across SMS, Email, and professional channels.</p>
        </div>
        <div className="flex items-center gap-2 bg-slate-50 p-1 sm:p-1.5 rounded-lg border border-slate-100 relative z-10 shadow-sm w-full lg:w-auto overflow-x-auto custom-scrollbar">
          {[
            { id: 'sms', icon: <FaCommentAlt />, label: 'SMS' },
            ...(!isReceptionist ? [
              { id: 'whatsapp', icon: <FaWhatsapp />, label: 'WhatsApp' }
            ] : []),
            { id: 'email', icon: <FaEnvelope />, label: 'Email' }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center justify-center gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-md text-[9px] sm:text-[10px] font-black uppercase tracking-widest transition-colors shrink-0 ${activeTab === tab.id ? 'bg-white text-clinicPrimary shadow-sm border border-slate-200' : 'text-slate-400 hover:text-slate-600 hover:bg-slate-100 border border-transparent'}`}
            >
              <span className="text-[10px] sm:text-[11px]">{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-clinicPrimary/5 rounded-full blur-2xl group-hover:bg-clinicPrimary/10 transition-colors duration-1000"></div>
      </Card>

      <Modal 
        isOpen={isCommModalOpen} 
        onClose={() => !isBroadcasting && setIsCommModalOpen(false)}
        title="Broadcast Notification"
        footer={
          <div className="flex gap-3 justify-end w-full">
            <Button variant="secondary" onClick={() => setIsCommModalOpen(false)} disabled={isBroadcasting}>Cancel</Button>
            <Button 
              variant="accent" 
              onClick={handleBroadcast} 
              leftIcon={isBroadcasting ? null : <FaPaperPlane />}
              disabled={isBroadcasting}
            >
              {isBroadcasting ? 'Sending...' : 'Send Now'}
            </Button>
          </div>
        }
      >
        <div className="space-y-4 p-0">
          <div className="space-y-1.5 sm:space-y-2">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Target Audience</label>
            <select className="w-full p-2 lg:p-2.5 bg-white border border-slate-200 rounded-lg text-[11px] sm:text-[12px] font-bold text-slate-700 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary shadow-sm transition-colors cursor-pointer">
              <option>Individual Patient Record</option>
              <option>Active Patient Database</option>
              <option>Pending Follow-up Queue</option>
              <option>Appointment Waitlist</option>
            </select>
          </div>
          <div className="space-y-1.5 sm:space-y-2">
            <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Message Content</label>
            <textarea className="w-full p-3 bg-white border border-slate-200 rounded-lg text-[11px] sm:text-[12px] font-bold text-slate-700 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary transition-colors h-24 sm:h-32 custom-scrollbar placeholder:text-slate-400 shadow-sm resize-none" placeholder="Enter clinical or administrative notification text..."></textarea>
          </div>
          <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg flex items-start gap-2.5">
             <FaInfoCircle className="text-blue-500 mt-0.5 shrink-0" size={12}/>
             <p className="text-[10px] sm:text-[11px] font-bold text-blue-700 leading-relaxed">Broadcast messages will be delivered through the primary communication channel set in the patient's profile preferences.</p>
          </div>
        </div>
      </Modal>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-6 min-h-[500px] h-auto lg:h-[calc(100vh-200px)]">
        <Card hover={false} className="lg:col-span-4 flex flex-col p-0 overflow-hidden border border-slate-100 shadow-sm bg-white h-full relative">
          <div className="p-3 sm:p-4 border-b border-slate-100 flex items-center justify-between bg-white z-10 relative">
            <h3 className="text-[10px] sm:text-[11px] font-black text-slate-900 uppercase tracking-widest">{activeTab} Conversations</h3>
            <Button 
              variant="accent" 
              size="icon" 
              className="h-8 w-8 rounded-lg shadow-sm transform hover:rotate-90 transition-transform active:scale-95"
              onClick={() => setIsCommModalOpen(true)}
            >
              <FaPlus size={10}/>
            </Button>
          </div>
          <div className="p-3 sm:p-4 pb-2 z-10 relative">
            <div className="relative group">
              <span className="absolute inset-y-0 left-3 flex items-center text-slate-400 group-focus-within:text-clinicPrimary transition-colors">
                <FaSearch size={12}/>
              </span>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search threads..."
                className="block w-full pl-8 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-[11px] sm:text-[12px] font-bold text-slate-600 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary transition-colors shadow-sm placeholder:text-slate-400"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar px-2 sm:px-3 pb-3 relative z-10">
            {filteredConversations.map((thread) => (
              <div 
                key={thread.id} 
                onClick={() => setActiveThreadId(thread.id)}
                className={`p-3 sm:p-3.5 rounded-xl mb-1 flex items-center gap-3 cursor-pointer transition-all border ${activeThreadId === thread.id ? 'bg-clinicPrimary/5 border-clinicPrimary/20 shadow-sm' : 'border-transparent hover:bg-slate-50'}`}
              >
                <div className="relative shrink-0">
                  <div className={`w-11 h-11 rounded-xl ${activeThreadId === thread.id ? 'bg-slate-900 text-clinicPrimary' : 'bg-slate-100 text-slate-600 border border-slate-200'} flex items-center justify-center font-black text-xs shadow-sm relative overflow-hidden transition-colors`}>
                     {thread.initial}
                  </div>
                  <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 border-2 border-white rounded-full shadow-sm ${thread.status === 'online' ? 'bg-emerald-500' : 'bg-slate-300'}`}></span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-0.5">
                    <p className={`text-[12px] font-black tracking-tight truncate ${activeThreadId === thread.id ? 'text-clinicPrimary' : 'text-slate-900'}`}>{thread.name}</p>
                    <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{thread.time}</span>
                  </div>
                  <div className="flex justify-between items-center gap-2">
                    <p className="text-[10px] text-slate-500 truncate font-bold tracking-tight opacity-70 flex-1">{thread.lastMsg}</p>
                    {thread.unreadCount > 0 && (
                        <span className="bg-clinicPrimary text-white text-[8px] font-black h-4 min-w-[16px] px-1 flex items-center justify-center rounded-full shadow-sm shadow-clinicPrimary/20">
                            {thread.unreadCount}
                        </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card hover={false} className="lg:col-span-8 flex flex-col p-0 overflow-hidden border border-slate-100 shadow-sm bg-white h-full relative">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-white z-20">
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="w-10 h-10 rounded-xl bg-clinicPrimary text-white flex items-center justify-center font-black text-sm shadow-sm relative overflow-hidden shrink-0">
                 {activeThread.initial}
              </div>
              <div>
                <p className="text-[13px] sm:text-[14px] font-black text-slate-900 tracking-tighter leading-none mb-1">{activeThread.name}</p>
                <div className="flex items-center gap-2">
                  <div className="relative flex items-center">
                    <span className={`w-2 h-2 ${activeThread.status === 'online' ? 'bg-emerald-500' : 'bg-slate-300'} rounded-full`}></span>
                  </div>
                  <p className="text-[8px] sm:text-[9px] text-slate-500 font-bold uppercase tracking-widest leading-none">Status: {activeThread.status === 'online' ? 'Online' : 'Offline'}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" size="icon" className="h-8 w-8 rounded-lg bg-white border border-slate-200 shadow-sm hover:text-clinicPrimary hover:bg-slate-50 transition-colors"><FaPhoneAlt size={12}/></Button>
              <Button variant="secondary" size="icon" className="h-8 w-8 rounded-lg bg-white border border-slate-200 shadow-sm hover:text-clinicPrimary hover:bg-slate-50 transition-colors"><FaInfoCircle size={12}/></Button>
            </div>
          </div>

          <div className="flex-1 p-4 sm:p-5 lg:p-6 overflow-y-auto custom-scrollbar bg-slate-50/50 space-y-6 sm:space-y-8 relative z-10">
            <div className="flex justify-center mb-2">
              <span className="px-3 py-1 bg-white border border-slate-200 rounded-md text-[8px] sm:text-[9px] font-black text-slate-400 uppercase tracking-widest shadow-sm">{new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </div>
            
            <div className="flex flex-col gap-6">
              {chatHistory.map((msg) => (
                <div key={msg.id} className={`flex flex-col ${msg.isMe ? 'items-end' : 'items-start'}`}>
                  <div className={`max-w-[85%] sm:max-w-[70%] flex gap-3 ${msg.isMe ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center text-[10px] font-black shadow-sm ${msg.isMe ? 'bg-clinicPrimary text-white' : 'bg-slate-900 text-clinicPrimary'}`}>
                        {msg.initial}
                    </div>
                    <div className="space-y-1">
                        <div className={`px-4 py-3 rounded-2xl shadow-sm ${msg.isMe ? 'bg-clinicPrimary text-white rounded-tr-sm' : 'bg-white border border-slate-100 text-slate-700 rounded-tl-sm'}`}>
                            <p className="text-[12px] font-bold leading-relaxed tracking-tight">{msg.text}</p>
                            {msg.file && (
                                <div className={`mt-2 p-2 rounded-lg flex items-center gap-2 border ${msg.isMe ? 'bg-white/10 border-white/20' : 'bg-slate-50 border-slate-100'}`}>
                                    <FaFileAlt size={12} className={msg.isMe ? 'text-white/70' : 'text-slate-400'} />
                                    <div className="min-w-0">
                                        <p className="text-[10px] font-bold truncate">{msg.file.name}</p>
                                        <p className="text-[8px] opacity-70">{msg.file.size}</p>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className={`flex items-center gap-2 px-1 ${msg.isMe ? 'justify-end' : ''}`}>
                            <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{msg.time}</span>
                            {msg.isMe && (
                                <span className={msg.status === 'read' ? 'text-blue-500' : 'text-slate-300'}>
                                    {msg.status === 'sent' ? <FaCheck size={8} /> : <FaCheckDouble size={8} />}
                                </span>
                            )}
                        </div>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
          </div>

          <div className="p-3 sm:p-4 border-t border-slate-100 bg-white relative z-20">
            {/* Template Dropdown */}
            {showTemplates && (
                <div className="absolute bottom-full left-4 mb-2 w-72 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden animate-in slide-in-from-bottom-2 duration-200 z-[999]">
                    <div className="p-3 bg-slate-50 border-b border-slate-100">
                        <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Select Template</h4>
                    </div>
                    <div className="max-h-60 overflow-y-auto custom-scrollbar">
                        {MESSAGE_TEMPLATES.map((t, idx) => (
                            <button
                                key={idx}
                                onClick={() => applyTemplate(t.text)}
                                className="w-full p-3 text-left border-b border-slate-50 hover:bg-slate-50 transition-colors last:border-0"
                            >
                                <p className="text-[11px] font-black text-clinicPrimary uppercase tracking-tight mb-1">{t.name}</p>
                                <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">{t.text}</p>
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Attachment Preview */}
            {selectedFile && (
                <div className="absolute bottom-full left-4 mb-2 p-2 bg-white border border-slate-100 rounded-lg shadow-lg flex items-center gap-3 animate-in slide-in-from-bottom-1">
                    <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center text-clinicPrimary">
                        <FaFileAlt size={14} />
                    </div>
                    <div className="min-w-0">
                        <p className="text-[10px] font-black text-slate-900 truncate max-w-[150px]">{selectedFile.name}</p>
                        <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">{selectedFile.size}</p>
                    </div>
                    <button onClick={() => setSelectedFile(null)} className="p-1 hover:text-rose-500 transition-colors">
                        <FaTimes size={12} />
                    </button>
                </div>
            )}

            <div className="flex flex-col gap-3">
                <div className="flex items-center gap-2">
                    <button 
                        onClick={() => setShowTemplates(!showTemplates)}
                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${showTemplates ? 'bg-clinicPrimary text-white' : 'bg-slate-50 text-slate-500 hover:bg-slate-100'}`}
                    >
                        Use Template
                    </button>
                    <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
                    <button onClick={() => fileInputRef.current?.click()} className="p-2 text-slate-400 hover:text-clinicPrimary transition-colors" title="Attach File">
                        <FaPaperclip size={14}/>
                    </button>
                    <button className="p-2 text-slate-400 hover:text-clinicPrimary transition-colors" title="Emoji">
                        <FaSmile size={14}/>
                    </button>
                </div>

                <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-xl border border-slate-200 focus-within:bg-white focus-within:border-clinicPrimary/30 transition-all">
                <input
                    type="text"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message..."
                    className="flex-1 bg-transparent border-none text-[12px] sm:text-[13px] font-bold tracking-tight px-3 py-1 outline-none text-slate-700 placeholder:text-slate-400"
                />
                <Button 
                    variant="accent" 
                    size="icon" 
                    onClick={handleSendMessage}
                    className="h-9 w-9 rounded-lg shadow-sm shrink-0 active:scale-95 transition-transform"
                >
                    <FaPaperPlane size={14}/>
                </Button>
                </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default Communication;
