import React, { useEffect, useState } from 'react';
import { FaDoorOpen, FaPlus, FaTrash, FaSave, FaArrowLeft } from 'react-icons/fa';
import { fetchApi } from '../config/api';
import { useNavigate } from 'react-router-dom';

const DEFAULT_ROOMS = ['Room 1 (Consult)', 'Room 2 (Rehab)', 'Room 3 (Assessment)', 'Studio A', 'Main Gym'];

const RoomSettings = () => {
  const navigate = useNavigate();
  const [rooms, setRooms] = useState(DEFAULT_ROOMS);
  const [newRoom, setNewRoom] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetchApi('/settings?keys=bookingRooms');
        if (!res || !res.ok) return;
        const data = await res.json();
        if (!data.success) return;
        const value = data?.data?.bookingRooms;
        if (Array.isArray(value) && value.length) setRooms(value);
      } catch (e) {
        // keep defaults on read failure
      }
    };
    load();
  }, []);

  const addRoom = () => {
    const trimmed = newRoom.trim();
    if (!trimmed) return;
    if (rooms.includes(trimmed)) return;
    setRooms((prev) => [...prev, trimmed]);
    setNewRoom('');
  };

  const removeRoom = (room) => {
    setRooms((prev) => prev.filter((r) => r !== room));
  };

  const saveRooms = async () => {
    setIsSaving(true);
    try {
      await fetchApi('/settings', {
        method: 'POST',
        body: JSON.stringify({ settings: { bookingRooms: rooms } })
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-5 animate-fade-in">
      <div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/settings')}
            className="w-10 h-10 bg-white rounded-full flex items-center justify-center border border-slate-200 text-slate-500 hover:text-clinicPrimary hover:border-clinicPrimary/30 hover:bg-clinicPrimary/5 transition-all outline-none shrink-0"
            title="Back to Settings"
          >
            <FaArrowLeft size={14} />
          </button>
          <div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Room Settings</h1>
            <p className="text-sm text-slate-500 mt-1">Manage rooms shown in appointment booking.</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={newRoom}
            onChange={(e) => setNewRoom(e.target.value)}
            placeholder="Add room name..."
            className="flex-1 h-10 px-3 bg-slate-50 border border-slate-200 rounded-lg text-sm font-medium text-slate-700 outline-none focus:border-clinicPrimary focus:ring-2 focus:ring-clinicPrimary/10"
          />
          <button
            onClick={addRoom}
            className="h-10 px-4 bg-slate-900 text-white rounded-lg text-[11px] font-bold uppercase tracking-wider hover:bg-clinicPrimary transition-colors flex items-center justify-center gap-2"
          >
            <FaPlus size={10} /> Add Room
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {rooms.map((room) => (
            <div key={room} className="flex items-center justify-between px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg">
              <div className="flex items-center gap-2">
                <FaDoorOpen size={10} className="text-slate-400" />
                <span className="text-sm font-semibold text-slate-700">{room}</span>
              </div>
              <button
                onClick={() => removeRoom(room)}
                className="w-7 h-7 rounded-md text-rose-500 hover:bg-rose-50 flex items-center justify-center"
                title={`Delete ${room}`}
              >
                <FaTrash size={10} />
              </button>
            </div>
          ))}
        </div>

        <div className="flex justify-end pt-1">
          <button
            onClick={saveRooms}
            disabled={isSaving}
            className="h-10 px-5 bg-clinicPrimary text-white rounded-lg text-[11px] font-bold uppercase tracking-wider hover:bg-clinicPrimary/90 transition-colors disabled:opacity-60 flex items-center gap-2"
          >
            <FaSave size={10} /> {isSaving ? 'Saving...' : 'Update Settings'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default RoomSettings;
