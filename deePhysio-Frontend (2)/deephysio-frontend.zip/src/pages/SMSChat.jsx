import React, { useState, useRef, useEffect } from 'react';
import { FaComments, FaSearch, FaPaperPlane, FaUserCircle, FaCheckDouble, FaPlus, FaPhoneAlt, FaInfoCircle, FaEllipsisV, FaRegSmile, FaPaperclip, FaHistory, FaCheck, FaTimes, FaCircle } from 'react-icons/fa';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { useToast } from '../context/ToastContext';
import { fetchApi } from '../config/api';

const SMSChat = () => {
    const { showToast } = useToast();
  const canWrite = ['admin', 'billing'].includes(sessionStorage.getItem('deephysio_role'));
  const [selectedChatId, setSelectedChatId] = useState(null);
  const role = sessionStorage.getItem('deephysio_role');


  const isTherapist = role === 'therapist';
  const isReceptionist = role === 'receptionist';
  const [messageText, setMessageText] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const scrollRef = useRef(null);

  const [chats, setChats] = useState([]);
  const [messages, setMessages] = useState([]);
  const [patients, setPatients] = useState([]);
  const [patientNameById, setPatientNameById] = useState({});
  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [newChatSearchTerm, setNewChatSearchTerm] = useState('');
  const [isEmojiOpen, setIsEmojiOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const fileInputRef = useRef(null);

  const emojis = ['😊', '👍', '🙏', '🏥', '📅', '💊', '✅', '👋', '💙', '💯'];

  useEffect(() => {
    const loadPatients = async () => {
      try {
        const response = await fetchApi('/patients');
        if (!response) return;
        const json = await response.json();
        const pList = json?.data || [];
        setPatients(pList);
        const map = {};
        pList.forEach((p) => {
          map[p.id] = `${p.firstName || p.first_name || ''} ${p.lastName || p.last_name || ''}`.trim() || `Patient ${p.id}`;
        });
        setPatientNameById(map);
      } catch (error) {
        setPatientNameById({});
      }
    };
    loadPatients();
  }, []);

  useEffect(() => {
    const loadThreads = async () => {
      try {
        const response = await fetchApi('/communication/threads?channel=sms');
        if (!response) return;
        const json = await response.json();
        const mapped = (json?.data || []).map((t) => ({
          id: t.id,
          patientId: t.patientId ?? t.patient_id,
          name: t.title || patientNameById[t.patientId ?? t.patient_id] || `Patient ${t.patientId ?? t.patient_id ?? 'Unknown'}`,
          initial: (t.title || patientNameById[t.patientId ?? t.patient_id] || `P${t.patientId ?? t.patient_id ?? 'U'}`).slice(0, 2).toUpperCase(),
          lastMsg: 'Open thread',
          time: new Date(t.updatedAt || t.updated_at).toLocaleString(),
          unread: 0,
          status: 'online',
          phone: `Patient ID: ${t.patientId ?? t.patient_id ?? 'Unknown'}`
        }));
        setChats(mapped);
        if (mapped.length && !selectedChatId) setSelectedChatId(mapped[0].id);
      } catch (error) {
        showToast('Failed to load SMS threads', 'error');
      }
    };
    loadThreads();
  }, [selectedChatId, showToast, patientNameById]);

  useEffect(() => {
    const loadMessages = async () => {
      if (!selectedChatId) return;
      try {
        const response = await fetchApi(`/communication/threads/${selectedChatId}/messages`);
        if (!response) return;
        const json = await response.json();
        const mapped = (json?.data || []).map((m) => ({
          id: m.id,
          chatId: m.threadId ?? m.thread_id,
          text: m.body,
          sender: m.direction === 'outbound' ? 'me' : 'them',
          time: new Date(m.createdAt || m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: m.delivery_status?.toLowerCase() || 'sent'
        }));
        setMessages(mapped);
      } catch (error) {
        console.error('Failed to load messages');
      }
    };

    loadMessages();
    const interval = setInterval(loadMessages, 10000); // Poll every 10 seconds
    return () => clearInterval(interval);
  }, [selectedChatId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, selectedChatId]);

  const handleSendMessage = async () => {
    if (!messageText.trim()) return;
    const active = chats.find((c) => c.id === selectedChatId);
    if (!active) return;
    try {
      const response = await fetchApi(`/communication/threads/${selectedChatId}/messages`, {
        method: 'POST',
        body: JSON.stringify({
          patientId: active.patientId,
          channel: 'sms',
          body: messageText
        })
      });
      if (!response) return;
      const json = await response.json();
      if (!json.success) {
        showToast(json.message || 'Message send failed', 'error');
        return;
      }
      setMessages((prev) => [...prev, {
        id: json.data.id,
        chatId: json.data.thread_id,
        text: json.data.body,
        sender: 'me',
        time: new Date(json.data.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'sent'
      }]);
      setMessageText('');
    } catch (error) {
      showToast('Message send failed', 'error');
    }
  };

  const filteredChats = chats.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()));
  const activeChat = chats.find(c => c.id === selectedChatId) || chats[0] || { name: 'No Thread', initial: 'NA', status: 'offline', phone: '' };
  const activeMessages = messages.filter(m => m.chatId === selectedChatId);

  const createNewThread = async (patient) => {
    try {
      const response = await fetchApi('/communication/threads', {
        method: 'POST',
        body: JSON.stringify({ 
          patientId: patient.id, 
          channel: 'sms', 
          title: `${patient.firstName} ${patient.lastName}` 
        })
      });
      if (!response) return;
      const json = await response.json();
      if (!json.success) {
        showToast(json.message || 'Thread create failed', 'error');
        return;
      }
      
      const newThread = {
        id: json.data.id,
        patientId: json.data.patient_id,
        name: json.data.title || `${patient.firstName} ${patient.lastName}`,
        initial: `${patient.firstName}`.slice(0, 2).toUpperCase(),
        lastMsg: 'Open thread',
        time: 'Just now',
        unread: 0,
        status: 'online',
        phone: patient.phone || `ID: ${patient.id}`
      };

      setChats((prev) => [newThread, ...prev]);
      setSelectedChatId(json.data.id);
      setIsNewChatModalOpen(false);
      setNewChatSearchTerm('');
    } catch (error) {
      showToast('Thread create failed', 'error');
    }
  };

  const handleAction = async (action) => {
    if (action === 'New Thread Initialization') {
      setIsNewChatModalOpen(true);
      return;
    }
    if (action === 'Attachment Node Sync') {
        fileInputRef.current?.click();
        return;
    }
    if (action === 'Emotional Feedback Node') {
        setIsEmojiOpen(!isEmojiOpen);
        return;
    }
    showToast(`Operational Logic: Initiating "${action}" for ${activeChat.name}. Node authenticated.`);
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
        setSelectedFile(file);
        showToast(`File "${file.name}" selected. It will be sent with your next message.`, 'success');
    }
  };

  const addEmoji = (emoji) => {
    setMessageText(prev => prev + emoji);
    setIsEmojiOpen(false);
  };

  return (
    <div className="h-[calc(100vh-100px)] flex flex-col lg:flex-row gap-4 animate-fade-in font-sans">
      {/* Sidebar - Chat List */}
      <Card className="w-full lg:w-96 flex flex-col p-0 overflow-hidden border-none shadow-premium bg-white h-full transition-all rounded-3xl">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-slate-50/20">
          <h1 className="text-[11px] font-black text-slate-900 tracking-[0.25em] uppercase leading-none flex items-center gap-4">
            <FaComments className="text-clinicPrimary" /> SMS Messages
          </h1>
            <button disabled={!canWrite} onClick={() => handleAction('New Thread Initialization')} className="w-11 h-11 bg-white text-clinicPrimary rounded-2xl border border-slate-100 flex items-center justify-center hover:bg-clinicPrimary hover:text-white hover:shadow-google transition-all active:scale-90 shadow-soft disabled:opacity-50">
            <FaPlus size={14}/>
          </button>
        </div>
        
        <div className="p-4 pb-2">
          <div className="relative group">
            <FaSearch className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-clinicPrimary transition-colors" size={14}/>
            <input 
              type="text" 
              placeholder="Search messages..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-16 pr-6 py-4 bg-white border border-slate-100 rounded-[24px] text-[13px] font-bold text-slate-600 outline-none focus:ring-4 focus:ring-clinicPrimary/5 transition-all shadow-inner-soft placeholder:text-slate-200" 
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 pb-8 space-y-2 lg:bg-transparent">
          {filteredChats.map(chat => (
            <div 
              key={chat.id}
              onClick={() => setSelectedChatId(chat.id)}
              className={`p-6 rounded-[32px] cursor-pointer transition-all duration-500 border relative group ${selectedChatId === chat.id ? 'bg-clinicPrimary/5 border-clinicPrimary/20 shadow-soft translate-x-1' : 'bg-white border-transparent hover:bg-slate-50'}`}
            >
              <div className="flex items-center gap-5">
                <div className="relative shrink-0">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-lg transition-all duration-500 shadow-soft ${selectedChatId === chat.id ? 'bg-clinicPrimary text-white rotate-3 scale-110' : 'bg-slate-50 text-slate-400 border border-slate-100'}`}>
                    {chat.initial}
                  </div>
                  {chat.status === 'online' && <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 border-4 border-white rounded-full shadow-lg"></span>}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className={`text-[15px] font-black tracking-tight truncate leading-none ${selectedChatId === chat.id ? 'text-clinicPrimary' : 'text-slate-800'}`}>{chat.name}</h4>
                    <span className="text-[10px] font-black uppercase tracking-widest text-slate-300 whitespace-nowrap ml-2">{chat.time}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-[12px] font-bold truncate pr-4 text-slate-400 opacity-80">{chat.lastMsg}</p>
                    {chat.unread > 0 && (
                      <span className="bg-clinicPrimary text-white text-[9px] font-black px-2 py-1 rounded-lg shadow-google animate-pulse">{chat.unread}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Main Chat Area */}
      <Card className="flex-1 flex flex-col p-0 overflow-hidden border-none shadow-premium bg-white h-full relative rounded-3xl border-l-4 border-l-clinicPrimary">
        {/* Chat Header */}
        <div className="p-6 border-b border-slate-50 flex items-center justify-between bg-white relative z-10">
          <div className="flex items-center gap-6">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-clinicPrimary/10 border border-clinicPrimary/20 flex items-center justify-center text-clinicPrimary font-black text-xl shadow-soft">
                 {activeChat.initial}
              </div>
              <div className={`absolute -bottom-1 -right-1 w-5 h-5 ${activeChat.status === 'online' ? 'bg-emerald-500' : 'bg-slate-300'} border-4 border-white rounded-full`}></div>
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-900 tracking-tighter uppercase leading-none mb-2">{activeChat.name}</h3>
              <div className="flex items-center gap-3">
                 <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.25em]">{activeChat.phone}</p>
                 <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                  <p className={`text-[9px] font-black uppercase tracking-[0.25em] ${activeChat.status === 'online' ? 'text-emerald-500' : 'text-slate-400'}`}>
                    {activeChat.status === 'online' ? 'Online' : 'Offline'}
                  </p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={() => handleAction('Voice Call Initiation')} className="w-12 h-12 flex items-center justify-center rounded-2xl bg-slate-50 text-slate-400 hover:text-clinicPrimary hover:shadow-google transition-all active:scale-90"><FaPhoneAlt size={16}/></button>
            <button onClick={() => handleAction('Operational Details Audit')} className="w-12 h-12 flex items-center justify-center rounded-2xl bg-slate-50 text-slate-400 hover:text-clinicPrimary hover:shadow-google transition-all active:scale-90"><FaEllipsisV size={16}/></button>
          </div>
        </div>

        {/* Messages */}
        <div 
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-6 space-y-8 bg-slate-50/20 custom-scrollbar relative"
        >
          <div className="flex justify-center mb-4">
             <span className="px-5 py-2 bg-white/80 border border-slate-100 rounded-full text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] shadow-premium backdrop-blur-sm">Messages: {new Date().toLocaleDateString()}</span>
          </div>

          {activeMessages.map(msg => (
            <div key={msg.id} className={`flex flex-col ${msg.sender === 'me' ? 'items-end' : 'items-start'} animate-in slide-in-from-bottom-2 duration-500`}>
              <div className={`max-w-[75%] p-4 md:p-6 rounded-3xl text-[15px] font-bold leading-relaxed tracking-tight group relative shadow-premium transition-all hover:translate-y-[-2px] ${msg.sender === 'me' ? 'bg-clinicPrimary text-white rounded-tr-none' : 'bg-white border border-slate-50 text-slate-700 rounded-tl-none'}`}>
                {msg.text}
                <div className={`absolute top-0 ${msg.sender === 'me' ? '-right-2' : '-left-2'} w-4 h-4 bg-inherit opacity-20`}></div>
              </div>
              <div className="flex items-center gap-3 mt-4 px-2 opacity-60">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{msg.time}</span>
                {msg.sender === 'me' && (
                   <span className="text-clinicPrimary flex items-center gap-1">
                      <FaCheckDouble size={10}/>
                      <span className="text-[9px] font-black uppercase tracking-widest leading-none pt-0.5">Verified</span>
                   </span>
                )}
              </div>
            </div>
          ))}
          
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-5 pointer-events-none">
             <FaComments size={300} className="text-clinicPrimary rotate-12" />
          </div>
        </div>

        {/* Input */}
        <div className="p-6 bg-white/60 backdrop-blur-xl border-t border-slate-50 relative z-10">
          {/* Emoji Picker Popover */}
          {isEmojiOpen && (
              <div className="absolute bottom-24 left-10 bg-white border border-slate-100 rounded-2xl shadow-premium p-3 flex gap-2 animate-in slide-in-from-bottom-2 duration-200 z-[100]">
                  {emojis.map(e => (
                      <button key={e} onClick={() => addEmoji(e)} className="text-xl hover:scale-125 transition-transform p-1">{e}</button>
                  ))}
              </div>
          )}

          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileSelect} 
            className="hidden" 
          />

          <div className="flex items-center gap-5 bg-white rounded-[32px] p-2 pl-8 border border-slate-100 shadow-premium transition-all duration-500 focus-within:shadow-google focus-within:border-clinicPrimary/30">
            <button onClick={() => handleAction('Attachment Node Sync')} className={`transition-colors p-2 active:scale-90 ${selectedFile ? 'text-clinicPrimary' : 'text-slate-300 hover:text-clinicPrimary'}`}>
                <FaPaperclip size={18}/>
                {selectedFile && <span className="absolute top-3 left-12 w-2 h-2 bg-emerald-500 rounded-full border border-white"></span>}
            </button>
            <button onClick={() => handleAction('Emotional Feedback Node')} className={`transition-colors p-2 active:scale-90 ${isEmojiOpen ? 'text-clinicPrimary' : 'text-slate-300 hover:text-clinicPrimary'}`}><FaRegSmile size={18}/></button>
            <input 
              type="text" 
              placeholder="Type a message..." 
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              className="flex-1 bg-transparent border-none outline-none text-[15px] font-bold text-slate-700 min-w-0 placeholder:text-slate-200 tracking-tight" 
            />
            <button 
              onClick={handleSendMessage}
              disabled={!canWrite}
              className="w-14 h-14 bg-clinicPrimary text-white rounded-[24px] shadow-google flex items-center justify-center hover:scale-110 active:scale-95 transition-all group overflow-hidden"
            >
              <FaPaperPlane size={18} className="transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
            </button>
          </div>
          <div className="mt-4 flex items-center justify-center gap-6">
              <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.4em] flex items-center gap-3">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-lg"></span>
                Secure Communication
              </p>
          </div>
        </div>
      </Card>
      {/* New Chat Modal */}
      {isNewChatModalOpen && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm animate-in fade-in duration-300">
           <div className="bg-white w-full max-w-md rounded-[32px] shadow-premium overflow-hidden animate-in zoom-in-95 duration-300">
              <div className="p-6 border-b border-slate-50 flex items-center justify-between">
                 <h3 className="text-[11px] font-black text-slate-900 uppercase tracking-widest">Select Patient for SMS</h3>
                 <button onClick={() => setIsNewChatModalOpen(false)} className="text-slate-300 hover:text-rose-500 transition-colors"><FaTimes size={18}/></button>
              </div>
              <div className="p-6">
                 <div className="relative mb-6 group">
                    <FaSearch className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-clinicPrimary" size={14}/>
                    <input 
                      type="text" 
                      placeholder="Search by name or email..."
                      className="w-full pl-16 pr-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-[13px] font-bold outline-none focus:ring-4 focus:ring-clinicPrimary/5"
                      value={newChatSearchTerm}
                      onChange={(e) => setNewChatSearchTerm(e.target.value)}
                      autoFocus
                    />
                 </div>
                 <div className="max-h-[300px] overflow-y-auto custom-scrollbar space-y-2 pr-2">
                    {patients.filter(p => 
                      `${p.firstName} ${p.lastName}`.toLowerCase().includes(newChatSearchTerm.toLowerCase()) ||
                      (p.email && p.email.toLowerCase().includes(newChatSearchTerm.toLowerCase()))
                    ).map(p => (
                       <div 
                         key={p.id}
                         onClick={() => createNewThread(p)}
                         className="p-4 bg-white border border-slate-100 rounded-2xl hover:border-clinicPrimary hover:bg-clinicPrimary/5 cursor-pointer transition-all flex items-center justify-between group"
                       >
                          <div className="flex items-center gap-4">
                             <div className="w-10 h-10 rounded-xl bg-slate-50 flex items-center justify-center text-slate-300 group-hover:text-clinicPrimary group-hover:bg-white transition-colors">
                                <FaUserCircle size={16}/>
                             </div>
                             <div>
                                <p className="text-[13px] font-black text-slate-700 uppercase tracking-tight">{p.firstName} {p.lastName}</p>
                                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{p.phone || 'No Phone Node'}</p>
                             </div>
                          </div>
                          <FaPlus size={10} className="text-slate-300 group-hover:text-clinicPrimary" />
                       </div>
                    ))}
                 </div>
              </div>
              <div className="p-6 bg-slate-50 flex justify-end">
                 <button onClick={() => setIsNewChatModalOpen(false)} className="px-6 py-3 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-slate-600">Cancel</button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default SMSChat;
