import React, { useEffect, useState } from 'react';
import { FaEnvelope, FaSearch, FaFilter, FaPlus, FaInbox, FaRegPaperPlane, FaStar, FaTrash, FaChevronRight, FaPaperclip, FaHistory, FaCheckCircle, FaExclamationCircle, FaUserCircle, FaReply, FaShare, FaPrint, FaArchive, FaSync } from 'react-icons/fa';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import Modal from '../components/ui/Modal';
import { fetchApi } from '../config/api';

const EmailMessages = () => {
  const [selectedEmailId, setSelectedEmailId] = useState(1);
  const [activeFolder, setActiveFolder] = useState('Inbox');
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [isForwardOpen, setIsForwardOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const role = sessionStorage.getItem('deephysio_role')?.toLowerCase();
  const canWrite = role === 'admin' || role === 'billing' || role === 'administrator';

  const isTherapist = role === 'therapist';
  const isReceptionist = role === 'receptionist';
  const [toast, setToast] = useState({ message: '', visible: false });
  const [isSending, setIsSending] = useState(false);

  const [patients, setPatients] = useState([]);
  const [patientNameById, setPatientNameById] = useState({});
  const [composeStep, setComposeStep] = useState('select-patient'); // 'select-patient' or 'compose'
  const [selectedPatientForCompose, setSelectedPatientForCompose] = useState(null);
  const [composeSearchTerm, setComposeSearchTerm] = useState('');

  const [emails, setEmails] = useState([]);

  const [composeData, setComposeData] = useState({ subject: '', message: '' });
  const [forwardData, setForwardData] = useState({ to: '' });
  const [attachment, setAttachment] = useState(null);

  useEffect(() => {
    const loadPatients = async () => {
      try {
        const response = await fetchApi('/patients');
        if (!response) return;
        const json = await response.json();
        const patientList = json?.data || [];
        setPatients(patientList);
        const map = {};
        patientList.forEach((p) => {
          map[p.id] = `${p.firstName || p.first_name || ''} ${p.lastName || p.last_name || ''}`.trim() || `Patient ${p.id}`;
        });
        setPatientNameById(map);
      } catch (error) {
        setPatientNameById({});
      }
    };
    loadPatients();
  }, []);

  const loadEmailData = async () => {
    try {
      const threadsRes = await fetchApi('/communication/threads?channel=email');
      if (!threadsRes) return;
      const threadsJson = await threadsRes.json();
      const threadList = threadsJson?.data || [];
      let all = [];
      for (const t of threadList) {
        const msgRes = await fetchApi(`/communication/threads/${t.id}/messages`);
        if (!msgRes) continue;
        const msgJson = await msgRes.json();
        const mapped = (msgJson?.data || []).map((m) => ({
          id: Number(m.id),
          sender: m.direction === 'outbound' ? 'You' : (patientNameById[m.patientId ?? m.patient_id] || `Patient ${m.patientId ?? m.patient_id ?? 'Unknown'}`),
          email: `patient-${m.patientId ?? m.patient_id ?? 'unknown'}@example.local`,
          subject: m.subject || '(no subject)',
          excerpt: String(m.body || '').slice(0, 80),
          date: new Date(m.createdAt || m.created_at).toLocaleString(),
          read: true,
          priority: 'Normal',
          content: m.body,
          folder: m.is_deleted ? 'Trash' : (m.direction === 'outbound' ? 'Sent' : 'Inbox'),
          isStarred: m.is_starred == 1 || m.is_starred === true || m.is_starred === '1' || m.is_starred === 'true'
        }));
        all = all.concat(mapped);
      }
      const unique = [];
      const seen = new Set();
      // Keep all messages unique by their database ID
      all.forEach(m => {
        if (!seen.has(m.id)) {
            unique.push(m);
            seen.add(m.id);
        }
      });
      setEmails(unique.sort((a, b) => (Number(b.id) - Number(a.id))));
    } catch (e) {
      showToast('Failed to sync emails');
    }
  };

  useEffect(() => {
    loadEmailData();
  }, [patientNameById]);

  const showToast = (message) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast({ message: '', visible: false }), 3000);
  };

  const folders = [
    { name: 'Inbox', icon: <FaInbox />, count: emails.filter(e => e.folder === 'Inbox' && !e.read).length },
    { name: 'Sent', icon: <FaRegPaperPlane />, count: emails.filter(e => e.folder === 'Sent').length },
    { name: 'Starred', icon: <FaStar />, count: emails.filter(e => e.isStarred).length },
    { name: 'Drafts', icon: <FaEnvelope />, count: emails.filter(e => e.folder === 'Drafts').length },
    { name: 'Trash', icon: <FaTrash />, count: emails.filter(e => e.folder === 'Trash').length },
  ];

  const handleAction = async (action, item) => {
    if (action === 'Deletion Signal') {
      try {
        await fetchApi(`/communication/messages/${item.id}/flags`, {
          method: 'PUT',
          body: JSON.stringify({ isDeleted: true })
        });
        setEmails(emails.map(e => e.id === item.id ? { ...e, folder: 'Trash' } : e));
        showToast('Moved to Trash');
      } catch (e) {
        showToast('Failed to delete email');
      }
    } else if (action === 'Archive Signal') {
      setEmails(emails.map(e => e.id === item.id ? { ...e, folder: 'Archive' } : e));
      showToast('Archived Successfully');
    } else if (action === 'Print Command') {
      window.print();
    } else if (action === 'Toggle Star') {
      try {
        const newStarred = !item.isStarred;
        const res = await fetchApi(`/communication/messages/${item.id}/flags`, {
          method: 'PUT',
          body: JSON.stringify({ isStarred: newStarred })
        });
        if (!res?.ok) throw new Error('Update failed');
        setEmails(emails.map(e => e.id.toString() === item.id.toString() ? { ...e, isStarred: newStarred } : e));
      } catch (e) {
        showToast('Failed to update Star');
      }
    } else if (action === 'Mark Read Unread') {
      setEmails(emails.map(e => e.id === item.id ? { ...e, read: !e.read } : e));
    }
  };

  const runMailSync = () => {
    setIsSyncing(true);
    setTimeout(async () => {
      await loadEmailData();
      setIsSyncing(false);
      showToast('Emails Synced Successfully');
    }, 2000);
  };

  const handleComposeSubmit = async () => {
    if (!selectedPatientForCompose) {
      showToast('Please select a recipient patient');
      return;
    }
    const patientId = selectedPatientForCompose.id;

    setIsSending(true);
    try {
      // 1. Create or Find Thread
      const threadRes = await fetchApi('/communication/threads', {
        method: 'POST',
        body: JSON.stringify({ 
          patientId, 
          channel: 'email', 
          title: `Communication with ${patientNameById[patientId] || 'Patient'}` 
        })
      });
      
      if (!threadRes) return;
      const threadJson = await threadRes.json();
      if (!threadJson.success) return showToast(threadJson.message || 'Thread setup failed');
      
      const threadId = threadJson.data.id;

      // 2. Send Message
      const msgRes = await fetchApi(`/communication/threads/${threadId}/messages`, {
        method: 'POST',
        body: JSON.stringify({ 
          patientId, 
          channel: 'email', 
          subject: composeData.subject, 
          body: composeData.message 
        })
      });
      
      if (!msgRes) return;
      const msgJson = await msgRes.json();
      
      if (!msgJson.success) return showToast(msgJson.message || 'Transmission failed');
      
      await loadEmailData();
      setIsComposeOpen(false);
      setComposeData({ subject: '', message: '' });
      setSelectedPatientForCompose(null);
      setComposeStep('select-patient');
      setAttachment(null);
      
      showToast('Email Transmitted Successfully');
    } catch (error) {
      showToast('Encryption/Transmission Node Error');
    } finally {
      setIsSending(false);
    }
  };

  const handleForwardSubmit = () => {
    showToast(`Email Forwarded to ${forwardData.to}`);
    setIsForwardOpen(false);
    setForwardData({ to: '' });
  };

  const filteredEmails = emails.filter(email => {
    const matchesFolder = activeFolder === 'Starred' ? email.isStarred : email.folder === activeFolder;
    const matchesSearch = email.sender.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          email.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = activeFilter === 'All' ? true : 
                          activeFilter === 'Unread' ? !email.read : 
                          activeFilter === 'Starred' ? email.isStarred : true;
    return matchesFolder && matchesSearch && matchesFilter;
  });

  const selectedEmail = emails.find(e => e.id === selectedEmailId) || filteredEmails[0] || null;

  return (
    <div className="space-y-4 sm:space-y-6 px-4 sm:px-5 lg:px-6 animate-fade-in font-sans relative">
      {/* Toast Notification */}
      {toast.visible && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 z-[9999] animate-bounce-in">
          <div className="bg-slate-900 text-white px-6 py-3 rounded-xl shadow-sm flex items-center gap-3">
             <FaCheckCircle className="text-clinicPrimary" size={12} />
             <span className="text-[10px] font-black uppercase tracking-widest">{toast.message}</span>
          </div>
        </div>
      )}

      <Card hover={false} className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-4 sm:p-5 border border-slate-100 shadow-none bg-white relative overflow-hidden group">
        <div className="relative z-10">
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tighter uppercase leading-none">Emails</h1>
          <p className="text-slate-500 font-bold mt-1.5 uppercase tracking-widest text-[9px] sm:text-[10px] opacity-80">Manage your clinical and administrative correspondence.</p>
        </div>
        <div className="flex gap-2 sm:gap-3 relative z-10 w-full lg:w-auto">
           <Button 
             variant="secondary" 
             className="flex-1 lg:flex-none rounded-lg h-9 sm:h-10 px-4 sm:px-5 border border-slate-200 shadow-sm hover:bg-slate-50 transition-colors text-[9px] lg:text-[10px] font-black uppercase tracking-widest" 
             onClick={runMailSync} 
             isLoading={isSyncing} 
             leftIcon={<FaSync size={10}/>}
           >
             {isSyncing ? 'Refreshing...' : 'Refresh'}
           </Button>
            <Button variant="accent" className="flex-1 lg:flex-none rounded-lg h-9 sm:h-10 px-4 sm:px-5 shadow-sm active:scale-95 transition-all text-[9px] lg:text-[10px] font-black uppercase tracking-widest" onClick={() => { setComposeStep('select-patient'); setIsComposeOpen(true); }} disabled={!canWrite} leftIcon={<FaPlus size={10}/>}>Compose Email</Button>
        </div>
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-clinicPrimary/5 rounded-full blur-2xl group-hover:bg-clinicPrimary/10 transition-colors duration-1000"></div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-6 min-h-[500px] h-[calc(100vh-200px)] lg:h-[calc(100vh-160px)]">
        {/* Sidebar */}
        <Card hover={false} className="lg:col-span-3 p-4 sm:p-5 flex flex-col h-full bg-white border border-slate-100 shadow-sm rounded-xl sm:rounded-2xl">
           <div className="mb-4 sm:mb-5 px-2 shrink-0">
              <h3 className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3 sm:mb-4">Directory Nodes</h3>
              <div className="space-y-1 sm:space-y-1.5">
                {folders.map(item => (
                  <button 
                    key={item.name}
                    onClick={() => { setActiveFolder(item.name); setSelectedEmailId(null); }}
                    className={`w-full flex items-center justify-between px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl transition-colors group ${activeFolder === item.name ? 'bg-clinicPrimary/10 text-clinicPrimary' : 'text-slate-500 hover:bg-slate-50'}`}
                  >
                    <div className="flex items-center gap-2 sm:gap-3">
                       <span className={`text-sm ${activeFolder === item.name ? 'text-clinicPrimary' : 'text-slate-400 group-hover:text-slate-500'}`}>{item.icon}</span>
                       <span className={`text-[10px] sm:text-[11px] font-black uppercase tracking-widest ${activeFolder === item.name ? 'text-clinicPrimary' : 'text-slate-600'}`}>{item.name}</span>
                    </div>
                    {item.count > 0 && (
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded-md ${activeFolder === item.name ? 'bg-clinicPrimary text-white' : 'bg-slate-100 text-slate-500'}`}>
                        {item.count}
                      </span>
                    )}
                  </button>
                ))}
              </div>
           </div>

           <div className="p-4 bg-slate-900 rounded-xl border border-white/5 relative overflow-hidden group cursor-pointer mt-auto shrink-0" onClick={() => showToast('Security Ledger Verified')}>
              <div className="relative z-10">
                 <p className="text-[10px] font-black text-white uppercase tracking-tight mb-1.5 flex items-center gap-2">
                   <FaCheckCircle className="text-clinicPrimary size={12}" /> Clinical Encryption
                 </p>
                 <p className="text-[8px] sm:text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">All inbound transmissions are encrypted via AES-256 clinical logic.</p>
              </div>
           </div>
        </Card>

        {/* Email List & Preview */}
        <div className="lg:col-span-9 flex flex-col lg:flex-row gap-4 sm:gap-6 h-full">
           {/* List */}
           <Card hover={false} className="flex-1 flex flex-col p-0 overflow-hidden border border-slate-100 shadow-sm bg-white rounded-xl sm:rounded-2xl shrink-0 lg:shrink h-[40vh] lg:h-full">
              <div className="p-3 sm:p-4 border-b border-slate-100 flex items-center gap-3 bg-white z-10 relative shrink-0">
                 <div className="relative flex-1 group">
                    <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-clinicPrimary transition-colors" size={12}/>
                    <input 
                      type="text" 
                      placeholder="Search emails..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-8 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-[11px] sm:text-[12px] font-bold text-slate-600 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary transition-colors shadow-sm placeholder:text-slate-400" 
                    />
                 </div>
                 <div className="relative">
                    <button 
                      onClick={() => setIsFilterOpen(!isFilterOpen)} 
                      className={`w-8 sm:w-9 h-8 sm:h-9 flex items-center justify-center border rounded-lg transition-colors shadow-sm active:scale-95 ${isFilterOpen ? 'bg-clinicPrimary text-white border-clinicPrimary' : 'bg-white border-slate-200 text-slate-400 hover:text-clinicPrimary hover:border-clinicPrimary/30'}`}
                    >
                      <FaFilter size={12}/>
                    </button>
                    {isFilterOpen && (
                      <div className="absolute top-10 right-0 w-40 bg-white rounded-xl shadow-sm border border-slate-200 z-50 overflow-hidden p-1.5">
                        {['All', 'Unread', 'Starred'].map(f => (
                          <button 
                            key={f}
                            onClick={() => { setActiveFilter(f); setIsFilterOpen(false); }}
                            className={`w-full text-left px-3 sm:px-4 py-2 rounded-lg text-[10px] sm:text-[11px] font-black uppercase tracking-widest transition-colors ${activeFilter === f ? 'bg-clinicPrimary/10 text-clinicPrimary' : 'text-slate-500 hover:bg-slate-50'}`}
                          >
                            {f}
                          </button>
                        ))}
                      </div>
                    )}
                 </div>
              </div>
              
              <div className="flex-1 overflow-y-auto custom-scrollbar relative z-0">
                 {filteredEmails.length > 0 ? filteredEmails.map(email => (
                   <div 
                     key={email.id} 
                     onClick={() => {
                        setSelectedEmailId(email.id);
                        if (!email.read) {
                          setEmails(emails.map(e => e.id === email.id ? { ...e, read: true } : e));
                        }
                     }}
                     className={`p-3 sm:p-4 lg:p-5 border-b border-slate-100 cursor-pointer transition-colors flex items-start gap-3 sm:gap-4 lg:gap-5 relative group ${selectedEmailId === email.id ? 'bg-clinicPrimary/5' : 'hover:bg-slate-50'}`}
                   >
                     {selectedEmailId === email.id && (
                        <div className="absolute left-0 top-0 bottom-0 w-1 bg-clinicPrimary"></div>
                     )}
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm sm:text-base transition-colors shadow-sm shrink-0 ${selectedEmailId === email.id ? 'bg-clinicPrimary text-white' : 'bg-slate-100 text-slate-400 border border-slate-200'}`}>
                         {email.sender[0]}
                      </div>
                      <div className="flex-1 min-w-0 pr-6">
                         <div className="flex justify-between items-center mb-1">
                            <h4 className={`text-[12px] sm:text-[13px] uppercase tracking-tight font-black truncate ${selectedEmailId === email.id ? 'text-clinicPrimary' : 'text-slate-900'}`}>{email.sender}</h4>
                            <span className="text-[8px] sm:text-[9px] font-black text-slate-400 uppercase tracking-widest shrink-0 ml-2">{email.date}</span>
                         </div>
                         <p className={`text-[11px] sm:text-[12px] truncate font-black tracking-tight mb-1 ${!email.read ? 'text-slate-900' : 'text-slate-500 opacity-80'}`}>{email.subject}</p>
                         <p className="text-[10px] sm:text-[11px] text-slate-500 font-bold truncate opacity-80">{email.excerpt}</p>
                      </div>
                      {!email.read && <div className="absolute top-4 right-4 w-2 h-2 bg-clinicPrimary rounded-full"></div>}
                   </div>
                 )) : (
                   <div className="p-10 text-center space-y-4">
                      <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mx-auto border border-dashed border-slate-200">
                         <FaEnvelope className="text-slate-300" size={16} />
                      </div>
                      <p className="text-[9px] font-black uppercase tracking-widest text-slate-400">Empty Transmission Node</p>
                   </div>
                 )}
              </div>
           </Card>

           {/* Preview */}
           <Card hover={false} className="flex-[1.5] flex flex-col p-0 overflow-hidden border border-slate-100 shadow-sm bg-slate-50 rounded-xl sm:rounded-2xl border-t-2 sm:border-t-4 border-t-clinicPrimary min-h-[50vh] lg:min-h-0">
              {selectedEmail ? (
                <>
                <div className="p-3 sm:p-4 lg:p-5 bg-white border-b border-slate-200 flex items-center justify-between sticky top-0 z-10 shrink-0">
                   <div className="flex items-center gap-2 sm:gap-3">
                      <button onClick={() => handleAction('Archive Signal', selectedEmail)} title="Archive" className="w-8 h-8 flex items-center justify-center rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-amber-500 hover:bg-slate-50 transition-colors shadow-sm"><FaArchive size={12}/></button>
                      <button onClick={() => handleAction('Deletion Signal', selectedEmail)} title="Delete" className="w-8 h-8 flex items-center justify-center rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-rose-500 hover:bg-slate-50 transition-colors shadow-sm"><FaTrash size={12}/></button>
                      <div className="w-px h-5 bg-slate-200 mx-1"></div>
                      <button onClick={() => handleAction('Mark Read Unread', selectedEmail)} title={selectedEmail.read ? "Mark as Unread" : "Mark as Read"} className="w-8 h-8 flex items-center justify-center rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-clinicPrimary hover:bg-slate-50 transition-colors shadow-sm">
                        {selectedEmail.read ? <FaEnvelope size={12}/> : <FaCheckCircle size={12}/>}
                      </button>
                      <button onClick={() => handleAction('Print Command', selectedEmail)} title="Print" className="w-8 h-8 flex items-center justify-center rounded-lg bg-white border border-slate-200 text-slate-400 hover:text-clinicPrimary hover:bg-slate-50 transition-colors shadow-sm"><FaPrint size={12}/></button>
                   </div>
                </div>

                <div className="flex-1 overflow-y-auto p-4 sm:p-5 lg:p-6 space-y-6 sm:space-y-8 bg-white/50 relative z-0">
                   <div className="space-y-4 sm:space-y-6 relative z-10">
                      <div className="flex items-start justify-between">
                         <div className="flex items-center gap-3 sm:gap-4">
                            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-slate-900 flex items-center justify-center text-clinicPrimary font-black text-base sm:text-lg shadow-sm shrink-0">
                               {selectedEmail.sender[0]}
                            </div>
                            <div>
                               <h2 className="text-sm sm:text-base font-black text-slate-900 tracking-tighter uppercase leading-none mb-0.5 sm:mb-1">{selectedEmail.sender}</h2>
                               <p className="text-[9px] sm:text-[10px] font-black text-slate-500 uppercase tracking-widest">{selectedEmail.email} • {selectedEmail.date}</p>
                            </div>
                         </div>
                         <Button 
                           variant="secondary" 
                           size="icon" 
                           className={`h-8 w-8 sm:h-9 sm:w-9 rounded-lg bg-white border border-slate-200 shadow-sm shrink-0 transition-colors ${selectedEmail.isStarred ? 'bg-amber-50 border-amber-200' : ''}`}
                           onClick={() => handleAction('Toggle Star', selectedEmail)}
                         >
                           <FaStar size={12} className={selectedEmail.isStarred ? 'text-amber-400' : 'text-slate-300'} />
                         </Button>
                      </div>

                      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden relative z-10">
                         <div className="p-4 sm:p-5 lg:p-6">
                            <h3 className="text-sm sm:text-base font-black text-slate-800 tracking-tighter leading-snug mb-4 sm:mb-5 border-l-2 sm:border-l-4 border-clinicPrimary pl-3 sm:pl-4">{selectedEmail.subject}</h3>
                            <div className="text-[12px] sm:text-[13px] text-slate-700 font-bold leading-relaxed whitespace-pre-wrap tracking-tight">
                               {selectedEmail.content}
                            </div>
                         </div>
                      </div>
                   </div>

                   <div className="flex items-center gap-3 sm:gap-4 relative z-10 px-1 lg:px-2">
                      <Button variant="accent" className="flex-1 h-9 sm:h-10 rounded-lg shadow-sm font-black uppercase tracking-widest text-[9px] sm:text-[10px]" leftIcon={<FaReply size={10}/>} onClick={() => showToast('Response Sent')}>Synchronize Response</Button>
                      <Button variant="secondary" className="flex-1 h-9 sm:h-10 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 shadow-sm font-black uppercase tracking-widest text-[9px] sm:text-[10px] transition-colors" leftIcon={<FaShare size={10}/>} onClick={() => setIsForwardOpen(true)}>Forward Node</Button>
                   </div>
                </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center p-10 text-center bg-transparent">
                   <div className="space-y-4">
                      <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center mx-auto shadow-sm border border-slate-200">
                         <FaRegPaperPlane className="text-slate-300" size={24} />
                      </div>
                      <div>
                        <p className="text-base font-black text-slate-400 uppercase tracking-tighter">Awaiting Selection</p>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Select an email to view its content.</p>
                      </div>
                   </div>
                </div>
              )}
           </Card>
        </div>
      </div>

      {/* Compose Modal */}
      <Modal 
        isOpen={isComposeOpen} 
        onClose={() => setIsComposeOpen(false)}
        title={composeStep === 'select-patient' ? "Select Recipient Node" : "Compose Transmission"}
        footer={
          <div className="flex gap-3 justify-end w-full px-2">
            <Button variant="secondary" onClick={() => setIsComposeOpen(false)}>Cancel</Button>
            {composeStep === 'compose' && (
              <Button variant="accent" onClick={handleComposeSubmit} disabled={!canWrite || isSending} isLoading={isSending} leftIcon={<FaRegPaperPlane size={10}/>}>
                {isSending ? 'Sending...' : 'Send Email'}
              </Button>
            )}
          </div>
        }
      >
        <div className="space-y-4 p-0 text-left font-sans">
           {composeStep === 'select-patient' ? (
             <div className="space-y-4">
                <div className="relative group">
                  <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-clinicPrimary" size={12}/>
                  <input 
                    type="text" 
                    placeholder="Search patient by name or ID..."
                    className="w-full pl-9 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-bold outline-none focus:ring-4 focus:ring-clinicPrimary/10 transition-all"
                    value={composeSearchTerm}
                    onChange={(e) => setComposeSearchTerm(e.target.value)}
                  />
                </div>
                <div className="max-h-[300px] overflow-y-auto space-y-2 custom-scrollbar pr-1">
                  {patients.filter(p => 
                    `${p.firstName} ${p.lastName}`.toLowerCase().includes(composeSearchTerm.toLowerCase()) ||
                    String(p.id).includes(composeSearchTerm)
                  ).map(p => (
                    <div 
                      key={p.id}
                      onClick={() => {
                        setSelectedPatientForCompose(p);
                        setComposeStep('compose');
                        setComposeSearchTerm('');
                      }}
                      className="p-3 bg-white border border-slate-100 rounded-xl hover:border-clinicPrimary hover:bg-clinicPrimary/5 cursor-pointer transition-all flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-3">
                         <div className="w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center text-slate-400 group-hover:text-clinicPrimary transition-colors">
                            <FaUserCircle size={14} />
                         </div>
                         <div>
                            <p className="text-[11px] font-black text-slate-700 uppercase tracking-tight">{p.firstName} {p.lastName}</p>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">ID: #{p.id} • {p.email || 'No Email'}</p>
                         </div>
                      </div>
                      <FaChevronRight size={10} className="text-slate-300 group-hover:text-clinicPrimary" />
                    </div>
                  ))}
                </div>
             </div>
           ) : (
             <div className="space-y-4 animate-slide-up">
                <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                   <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-clinicPrimary">
                        <FaUserCircle size={14} />
                      </div>
                      <div>
                        <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Target Node</p>
                        <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight">{selectedPatientForCompose?.firstName} {selectedPatientForCompose?.lastName}</p>
                      </div>
                   </div>
                   <button onClick={() => setComposeStep('select-patient')} className="text-[9px] font-black text-clinicPrimary uppercase tracking-widest hover:underline">Change</button>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Transmission Header</label>
                  <input 
                    type="text" 
                    value={composeData.subject}
                    onChange={(e) => setComposeData({...composeData, subject: e.target.value})}
                    placeholder="Protocol Handshake: Initial Clinical Sync" 
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg text-[11px] font-bold text-slate-700 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary transition-colors" 
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Payload Content</label>
                  <textarea 
                    value={composeData.message}
                    onChange={(e) => setComposeData({...composeData, message: e.target.value})}
                    placeholder="Enter clinical or administrative operational data..." 
                    className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-[11px] font-bold text-slate-700 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary transition-colors h-32 custom-scrollbar resize-none"
                  />
                </div>

                <label className="flex items-center justify-between gap-2 px-3 py-3 bg-blue-50/50 hover:bg-blue-100/50 cursor-pointer rounded-xl border border-blue-100 shadow-sm transition-colors">
                  <div className="flex items-center gap-2 overflow-hidden">
                    <FaPaperclip className="text-blue-500 shrink-0" size={12}/>
                    <p className="text-[9px] font-black text-blue-700 uppercase tracking-widest truncate">
                        {attachment ? attachment.name : 'Attach Clinical Documentation Nodes'}
                    </p>
                  </div>
                  {attachment && (
                    <button 
                      type="button" 
                      onClick={(e) => { e.preventDefault(); setAttachment(null); }}
                      className="text-rose-400 hover:text-rose-600 font-bold text-[9px] uppercase tracking-widest shrink-0 ml-2"
                    >
                      Remove
                    </button>
                  )}
                  <input 
                    type="file" 
                    className="hidden" 
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setAttachment(e.target.files[0]);
                      }
                    }}
                  />
                </label>
             </div>
           )}
        </div>
      </Modal>

      {/* Forward Modal */}
      <Modal 
        isOpen={isForwardOpen} 
        onClose={() => setIsForwardOpen(false)}
        title="Forward Operational Node"
        footer={
          <div className="flex gap-3 justify-end w-full px-2">
            <Button variant="secondary" onClick={() => setIsForwardOpen(false)}>Abort</Button>
            <Button variant="accent" onClick={handleForwardSubmit} leftIcon={<FaRegPaperPlane size={10} />}>Forward Sequence</Button>
          </div>
        }
      >
        <div className="space-y-4 p-0 text-left font-sans">
           <div className="space-y-1.5 sm:space-y-2">
              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest ml-1">Target Node Address</label>
              <div className="relative group">
                 <FaUserCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 transition-colors" size={12}/>
                 <input 
                   type="text" 
                   value={forwardData.to}
                   onChange={(e) => setForwardData({...forwardData, to: e.target.value})}
                   placeholder="recipient@node.com" 
                   className="w-full pl-8 pr-4 py-2 sm:py-2.5 bg-white border border-slate-200 rounded-lg text-[11px] sm:text-[12px] font-bold text-slate-700 outline-none focus:ring-2 focus:ring-clinicPrimary/10 focus:border-clinicPrimary text-shadow transition-colors placeholder:text-slate-400" 
                 />
              </div>
           </div>
           <div className="p-4 bg-white border border-slate-200 rounded-xl italic text-[11px] sm:text-[12px] text-slate-500 shadow-sm font-bold">
              "Forwarding: {selectedEmail?.subject}"
           </div>
        </div>
      </Modal>
    </div>
  );
};


export default EmailMessages;
