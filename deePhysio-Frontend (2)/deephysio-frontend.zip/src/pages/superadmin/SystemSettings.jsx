import React, { useState, useEffect, useRef } from 'react';
import { FaUser, FaBuilding, FaLock, FaBullhorn, FaCamera } from 'react-icons/fa';
import { fetchApi } from '../../config/api';
import { useToast } from '../../context/ToastContext';

const Toggle = ({ checked, onChange }) => (
  <label className="relative inline-flex items-center cursor-pointer">
    <input type="checkbox" className="sr-only peer" checked={checked || false} onChange={onChange} />
    <div className={`w-8 h-4 rounded-full peer ${checked ? 'bg-blue-500' : 'bg-slate-200'} after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:rounded-full after:h-3 after:w-3 after:transition-all ${checked ? 'after:translate-x-4' : ''}`}></div>
  </label>
);

const notificationItems = [
  { title: 'Welcome Note', sub: 'Sent automatically to new members on registration.' },
  { title: 'Invoice Bills', sub: 'Sent automatically to members when recording a plan payment.' },
  { title: 'Marketing Campaigns', sub: 'Sent for scheduled marketing campaigns or blasts.' },
  { title: 'Free Trial Registration Alerts', sub: 'Sent automatically to the Super Admin when a new Clinic registers for a free trial.' },
  { title: 'Paid Subscription Expiry / Renewal Alerts', sub: 'Sent automatically to Clinic Admins (Owners) when their SaaS plan is expiring.' },
  { title: 'Paid Payment Invoice / Receipt', sub: 'Sent automatically to Clinic Owners with PDF Tax Invoice link when subscription payment is received.' }
];

const SystemSettings = () => {
  const { showToast } = useToast();
  const fileInputRef = useRef(null);

  const [isLoading, setIsLoading] = useState(true);
  const [profile, setProfile] = useState({ name: '', email: '', photo: '' });
  const [business, setBusiness] = useState({ businessName: '', gstNumber: '', mobileNumber: '', businessAddress: '' });
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [notifications, setNotifications] = useState({});

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const response = await fetchApi('/saas/settings');
      if (response.success && response.data) {
        setProfile(response.data.profile || { name: '', email: '', photo: '' });
        setBusiness(response.data.business || { businessName: '', gstNumber: '', mobileNumber: '', businessAddress: '' });
        
        // Initialize notifications if empty
        let notifs = response.data.notifications || {};
        if (Object.keys(notifs).length === 0) {
          notificationItems.forEach(item => {
            notifs[item.title] = { email: true, whatsapp: true, push: true };
          });
        }
        setNotifications(notifs);
      }
    } catch (error) {
      console.error("Failed to load settings", error);
      showToast('error', 'Failed to load settings');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhotoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        showToast('error', 'Image size should be less than 2MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfile(prev => ({ ...prev, photo: reader.result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveProfileBusiness = async () => {
    try {
      showToast('info', 'Saving changes...');
      const response = await fetchApi('/saas/settings', {
        method: 'PUT',
        body: JSON.stringify({ profile, business })
      });
      if (response.success) {
        showToast('success', 'Profile and Business details updated!');
      } else {
        showToast('error', response.message || 'Failed to update settings');
      }
    } catch (error) {
      showToast('error', 'An error occurred while saving.');
    }
  };

  const handleSavePassword = async () => {
    if (!passwords.currentPassword || !passwords.newPassword || !passwords.confirmPassword) {
      showToast('error', 'Please fill all password fields.');
      return;
    }
    if (passwords.newPassword !== passwords.confirmPassword) {
      showToast('error', 'New passwords do not match.');
      return;
    }

    try {
      showToast('info', 'Updating password...');
      const response = await fetchApi('/saas/settings/password', {
        method: 'PUT',
        body: JSON.stringify({
          currentPassword: passwords.currentPassword,
          newPassword: passwords.newPassword
        })
      });
      if (response.success) {
        showToast('success', 'Password updated successfully!');
        setPasswords({ currentPassword: '', newPassword: '', confirmPassword: '' });
      } else {
        showToast('error', response.message || 'Failed to update password');
      }
    } catch (error) {
      showToast('error', 'An error occurred while updating password.');
    }
  };

  const handleSaveChannels = async () => {
    try {
      showToast('info', 'Saving notification channels...');
      const response = await fetchApi('/saas/settings', {
        method: 'PUT',
        body: JSON.stringify({ notifications })
      });
      if (response.success) {
        showToast('success', 'Notification channels updated!');
      } else {
        showToast('error', response.message || 'Failed to update channels');
      }
    } catch (error) {
      showToast('error', 'An error occurred while saving channels.');
    }
  };

  const handleNotificationChange = (title, channel, checked) => {
    setNotifications(prev => ({
      ...prev,
      [title]: {
        ...(prev[title] || { email: true, whatsapp: true, push: true }),
        [channel]: checked
      }
    }));
  };

  if (isLoading) {
    return <div className="p-6 text-center text-slate-500">Loading settings...</div>;
  }

  return (
    <div className="p-4 md:p-6 bg-slate-50/50 min-h-screen space-y-4 font-sans">
      <h1 className="text-2xl font-black text-slate-800 tracking-tight">Settings</h1>

      {/* PROFILE SECTION */}
      <div className="bg-white border border-slate-200 shadow-sm rounded">
        <div className="bg-slate-50 px-4 py-2 border-b border-slate-200 flex items-center gap-2">
          <FaUser className="text-slate-500" />
          <h2 className="font-bold text-slate-700 text-sm">My Profile</h2>
        </div>
        <div className="p-4 flex flex-col md:flex-row gap-6">
          <div className="flex flex-col items-center">
            <div className="w-24 h-24 rounded-full border-4 border-yellow-400 overflow-hidden bg-slate-100 flex items-center justify-center relative group">
              {profile.photo ? (
                <img src={profile.photo} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <span className="text-4xl font-black text-yellow-500">{profile.name ? profile.name.charAt(0).toUpperCase() : 'KT'}</span>
              )}
              <div className="absolute inset-0 bg-black/40 hidden group-hover:flex items-center justify-center cursor-pointer transition-all" onClick={() => fileInputRef.current.click()}>
                <FaCamera className="text-white text-xl" />
              </div>
            </div>
            <input type="file" ref={fileInputRef} onChange={handlePhotoUpload} accept="image/*" className="hidden" />
            <button onClick={() => fileInputRef.current.click()} className="mt-2 text-[10px] font-bold border border-slate-300 px-3 py-1 rounded bg-slate-50 hover:bg-slate-100">
              Change Photo
            </button>
          </div>
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">Full Name</label>
              <input type="text" value={profile.name} onChange={e => setProfile({...profile, name: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">Email</label>
              <input type="email" value={profile.email} onChange={e => setProfile({...profile, email: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
            </div>
          </div>
        </div>
      </div>

      {/* BUSINESS DETAILS SECTION */}
      <div className="bg-white border border-slate-200 shadow-sm rounded">
        <div className="bg-slate-50 px-4 py-2 border-b border-slate-200 flex items-center gap-2">
          <FaBuilding className="text-slate-500" />
          <h2 className="font-bold text-slate-700 text-sm">Business Details</h2>
        </div>
        <div className="p-4 space-y-4">
          <p className="text-[10px] text-slate-500">These details will be printed on the Email/Payment Invoices sent to your clients.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">Business Name</label>
              <input type="text" value={business.businessName} onChange={e => setBusiness({...business, businessName: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">GST Number</label>
              <input type="text" value={business.gstNumber} onChange={e => setBusiness({...business, gstNumber: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-500 mb-1">Mobile Number</label>
              <input type="text" value={business.mobileNumber} onChange={e => setBusiness({...business, mobileNumber: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
            </div>
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">Business Address</label>
            <textarea value={business.businessAddress} onChange={e => setBusiness({...business, businessAddress: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none resize-none focus:border-blue-400" rows="2"></textarea>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row justify-end gap-3 mt-4">
        <button className="w-full sm:w-auto bg-slate-500 text-white px-5 py-2 rounded text-sm font-bold shadow-sm hover:bg-slate-600">Cancel</button>
        <button onClick={handleSaveProfileBusiness} className="w-full sm:w-auto bg-[#d9531e] text-white px-5 py-2 rounded text-sm font-bold shadow-sm hover:bg-[#c04313]">Save Profile & Business</button>
      </div>

      {/* CHANGE PASSWORD SECTION */}
      <div className="bg-white border border-slate-200 shadow-sm rounded">
        <div className="bg-slate-50 px-4 py-2 border-b border-slate-200 flex items-center gap-2">
          <FaLock className="text-slate-500" />
          <h2 className="font-bold text-slate-700 text-sm">Change Password</h2>
        </div>
        <div className="p-4 space-y-3 max-w-md">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">Current Password</label>
            <input type="password" value={passwords.currentPassword} onChange={e => setPasswords({...passwords, currentPassword: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">New Password</label>
            <input type="password" value={passwords.newPassword} onChange={e => setPasswords({...passwords, newPassword: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
          </div>
          <div>
            <label className="block text-[10px] font-bold text-slate-500 mb-1">Confirm New Password</label>
            <input type="password" value={passwords.confirmPassword} onChange={e => setPasswords({...passwords, confirmPassword: e.target.value})} className="w-full border border-slate-200 rounded px-3 py-1.5 text-sm outline-none focus:border-blue-400" />
          </div>
          <div className="pt-2">
             <button onClick={handleSavePassword} className="bg-slate-800 text-white px-4 py-1.5 rounded text-[11px] font-bold shadow-sm hover:bg-slate-900">Update Password</button>
          </div>
        </div>
      </div>

      {/* NOTIFICATIONS SECTION */}
      <div className="bg-white border border-slate-200 shadow-sm rounded">
        <div className="bg-slate-50 px-4 py-2 border-b border-slate-200 flex items-center gap-2">
          <FaBullhorn className="text-red-500" />
          <h2 className="font-bold text-slate-700 text-sm">Global Notification Channel Manager</h2>
        </div>
        <div className="p-4">
          <p className="text-[10px] text-slate-500 mb-4">Select which communication channels (Email, WhatsApp, or App Push Notification) will be used to send system notifications.</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left border border-slate-200">
              <thead className="bg-slate-50 text-slate-500 text-[10px] font-black uppercase">
                <tr>
                  <th className="px-4 py-2 border-b border-slate-200 border-r w-1/2">Notification Type</th>
                  <th className="px-4 py-2 border-b border-slate-200 border-r text-center">Email</th>
                  <th className="px-4 py-2 border-b border-slate-200 border-r text-center">WhatsApp</th>
                  <th className="px-4 py-2 border-b border-slate-200 text-center">App Push</th>
                </tr>
              </thead>
              <tbody className="text-[10px] font-bold text-slate-600">
                {notificationItems.map((item, i) => (
                  <tr key={i} className="border-b border-slate-200">
                    <td className="px-4 py-3 border-r border-slate-200">
                      <div className="text-slate-800 text-[11px]">{item.title}</div>
                      <div className="text-[9px] text-slate-400 font-medium">{item.sub}</div>
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-center">
                      <Toggle checked={notifications[item.title]?.email} onChange={(e) => handleNotificationChange(item.title, 'email', e.target.checked)} />
                    </td>
                    <td className="px-4 py-3 border-r border-slate-200 text-center">
                       <Toggle checked={notifications[item.title]?.whatsapp} onChange={(e) => handleNotificationChange(item.title, 'whatsapp', e.target.checked)} />
                    </td>
                    <td className="px-4 py-3 text-center">
                       <Toggle checked={notifications[item.title]?.push} onChange={(e) => handleNotificationChange(item.title, 'push', e.target.checked)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex justify-end">
            <button onClick={handleSaveChannels} className="bg-[#d9531e] text-white px-4 py-1.5 rounded text-[11px] font-bold shadow-sm hover:bg-[#c04313]">Save Channels</button>
          </div>
        </div>
      </div>

    </div>
  );
};

export default SystemSettings;
