// Global API configuration
const API_BASE_URL = (
  import.meta.env.VITE_API_BASE_URL ||
  'https://deephysioclinical-production.up.railway.app/api'
).replace(/\/$/, '');

/**
 * Get standard auth headers with Bearer token
 */
export const getAuthHeaders = () => {
  const token = sessionStorage.getItem("token");
  const isValidToken = token && token !== 'null' && token !== 'undefined';

  return {
    "Content-Type": "application/json",
    ...(isValidToken ? { Authorization: `Bearer ${token}` } : {}),
  };
};

/**
 * Global fetch wrapper with 401 interception
 */
export const fetchApi = async (url, options = {}) => {
  const token = sessionStorage.getItem('token');

  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;

  const headers = {
    ...getAuthHeaders(),
    ...(options.headers || {})
  };

  try {
    const response = await fetch(fullUrl, {
      ...options,
      headers
    });

    if (response.status === 401 && !url.includes('auth/login')) {
      // Token expired or invalid -> log out and clear session fully
      sessionStorage.removeItem("token");
      sessionStorage.removeItem("deephysio_user");
      sessionStorage.removeItem("deephysio_role");

      // Avoid redirect loop by checking if we're not already on login
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
      return null; // Return null to prevent further execution in components
    }


    return response;
  } catch (error) {
    console.error("Global API Error:", error);
    throw error;
  }
};

export default API_BASE_URL;
